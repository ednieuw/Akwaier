import Foundation
import Combine
import AkwaierKern

/// Eén regel in het meldingenvak.
struct Melding: Identifiable {
    let id: Int
    let tekst: String
    /// Regels die inspringen horen bij de melding erboven (fusie en uitkering).
    var ingesprongen: Bool { tekst.hasPrefix(" ") }
}

/// Een keten zoals het gegevenspaneel hem laat zien.
struct Ketenstand: Identifiable {
    let nummer: Int
    let letter: Character
    let tegels: Int
    let prijs: Int
    /// De grootste en de op één na grootste aandeelhouder; 0 als er niemand is.
    let eerste: Int
    let tweede: Int
    var bestaat: Bool { tegels > 0 }
    var id: Int { nummer }
}

struct Spelerstand: Identifiable {
    let nummer: Int
    let naam: String
    let geld: Int
    let vermogen: Int
    let aandelen: [Int]
    let mens: Bool
    var id: Int { nummer }
}

/// Eén van de acht stenen in de hand.
struct Handsteen: Identifiable {
    let plaats: Int
    let steen: Int
    let vak: String
    /// Onwaar als je die steen nu nergens kwijt kunt.
    let mag: Bool
    var id: Int { plaats }
}

/// Een afdruk van de spelstand voor het scherm. De kern is een klasse en zegt
/// zelf niet wanneer er iets verandert; door na elke zet een nieuwe afdruk te
/// maken weet SwiftUI precies wat er opnieuw getekend moet worden — en blijft
/// de kern vrij van schermcode.
struct Stand {
    /// 225 vakjes, plaats (rij - 1) * 15 + (kolom - 1).
    var vakken: [Int] = Array(repeating: Regels.leeg, count: 225)
    /// Op welk vakje een eigen steen ligt: 1 tot en met 8, anders 0.
    var eigenSteen: [Int] = Array(repeating: 0, count: 225)
    /// Of je op dat vakje mag leggen.
    var eigenMag: [Bool] = Array(repeating: false, count: 225)

    var ketens: [Ketenstand] = []
    var spelers: [Spelerstand] = []
    var hand: [Handsteen] = []
    var zak = 0
    var beurt = 0
    var aanDeBeurt = 0
    var klaar = false
    var eindreden = ""
    var eindstand: [(nummer: Int, naam: String, vermogen: Int)] = []

    static func plaats(kolom x: Int, rij y: Int) -> Int { (y - 1) * Regels.grootte + (x - 1) }
}

/// Alles wat het scherm van een partij moet weten, en niets meer. De regels
/// blijven in `AkwaierKern`; dit model roept ze aan en bewaart wat er gebeurd is.
@MainActor
final class Spelmodel: ObservableObject {

    /// Wat er nu van de speler gevraagd wordt.
    enum Fase: Equatable {
        case start                  // het startvenster staat open
        case computerSpeelt
        case kiezen                 // kies een steen
        case gekozen(Int)           // handplaats gekozen: leggen of stichten?
        case stichten(Int)          // welke keten wordt het?
        case gelijkspel(Int, [Int]) // twee even grote ketens: welke blijft?
        case passen                 // geen enkele steen kan weg
        case kopenKeten             // koop aandelen: welke keten?
        case kopenAantal(Int)       // ... en hoeveel?
        case klaar
    }

    @Published private(set) var stand = Stand()
    @Published private(set) var fase: Fase = .start
    @Published private(set) var meldingen: [Melding] = []

    /// Wordt opgehoogd als de taal verandert, zodat het hele scherm opnieuw
    /// wordt opgebouwd; de teksten in `Taal` zijn geen waarneembare toestand.
    @Published private(set) var taalversie = 0

    @Published var snel = false

    /// De gekozen weergave wordt bewaard, zodat het spel de volgende keer begint
    /// zoals je het achterliet. De eerste keer is dat Retro BBC.
    @Published var weergave: Weergave = .retro {
        didSet { Scorelijst.bewaarWeergave(weergave.rawValue) }
    }

    /// Of er een partij loopt, en op welke plaats de mens zit; 0 in kijkmodus.
    ///
    /// Dit staan aparte eigenschappen en geen `spel != nil`: `spel` zelf is geen
    /// waarneembare toestand, dus het scherm zou een nieuwe partij anders niet
    /// zien beginnen.
    @Published private(set) var loopt = false
    @Published private(set) var mensPlaats = 0

    var kijkt: Bool { mensPlaats == 0 }

    /// De spelkern zelf blijft buiten de waarneming: het scherm kijkt naar de
    /// afdruk `stand`, die na elke zet opnieuw gemaakt wordt.
    private var spel: Spel?
    private var taak: Task<Void, Never>?
    private var teller = 0

    var mensNaam: String {
        guard mensPlaats > 0 else { return "" }
        return stand.spelers.first { $0.nummer == mensPlaats }?.naam ?? ""
    }

    init() {
        Scorelijst.laadTaal()
        // Toekennen in init zet `didSet` niet aan; er wordt hier dus niets
        // teruggeschreven wat er net uit kwam.
        weergave = Weergave(rawValue: Scorelijst.laadWeergave()) ?? .retro
    }

    /// De naam waarmee de vorige partij gespeeld is.
    var laatsteNaam: String { Scorelijst.laadNaam() }

    // MARK: - taal

    var engels: Bool {
        get { Taal.engels }
        set {
            guard newValue != Taal.engels else { return }
            Taal.engels = newValue
            Scorelijst.bewaarTaal()
            taalversie += 1
        }
    }

    // MARK: - een partij beginnen en beëindigen

    func nieuwSpel(naam: String, plaats: Int, meedoen: Bool) {
        Scorelijst.bewaarNaam(naam)
        taak?.cancel()
        spel = Spel(mensPlaats: meedoen ? plaats : 0, mensNaam: naam)
        mensPlaats = meedoen ? plaats : 0
        loopt = true
        meldingen = []
        teller = 0
        ververs()
        if !meedoen { meld([Taal.kijkmodus]) }
        volgende()
    }

    func naarStart() {
        taak?.cancel()
        taak = nil
        spel = nil
        loopt = false
        mensPlaats = 0
        stand = Stand()
        meldingen = []
        fase = .start
    }

    /// De volgende speler aan zet, of het einde van de partij.
    private func volgende() {
        guard let spel else { return }
        let nr = spel.volgendeSpeler()
        ververs()
        guard nr != 0 else { return beeindig() }
        if nr == spel.mensPlaats {
            beginMensbeurt()
        } else {
            speelComputer(nr)
        }
    }

    private func speelComputer(_ nr: Int) {
        fase = .computerSpeelt
        taak = Task { [weak self] in
            guard let self else { return }
            try? await Task.sleep(for: .milliseconds(self.snel ? 40 : 550))
            guard !Task.isCancelled, let spel = self.spel else { return }
            self.meld(spel.computerBeurt(nr))
            self.ververs()
            self.volgende()
        }
    }

    private func beginMensbeurt() {
        guard let spel else { return }
        fase = spel.geldigePlaatsen(spel.mensPlaats).isEmpty ? .passen : .kiezen
    }

    private func beeindig() {
        guard let spel else { return }
        meld([Taal.einde(spel.eindreden)])
        let eind = spel.eindstand()
        Scorelijst.bijwerken(eind.map { (naam: $0.naam, vermogen: $0.vermogen) })
        fase = .klaar
        ververs()
    }

    // MARK: - de beurt van de mens

    /// Een steen kiezen, via de hand of via het bord.
    func kies(plaats: Int) {
        guard case .kiezen = fase else { return }
        guard let spel, spel.hand(spel.mensPlaats, plaats) != 0 else { return }
        fase = .gekozen(plaats)
    }

    /// Tikken op een vakje: als daar een eigen steen ligt, is die gekozen.
    func kiesVak(kolom x: Int, rij y: Int) {
        guard case .kiezen = fase, let spel, mensPlaats > 0 else { return }
        for s in 0..<Regels.handGrootte {
            let t = spel.hand(mensPlaats, s)
            guard t != 0 else { continue }
            let p = Regels.tegelPositie(t)
            if p.x == x && p.y == y { kies(plaats: s); return }
        }
    }

    func annuleer() {
        if case .gekozen = fase { fase = .kiezen }
        if case .stichten = fase { fase = .kiezen }
    }

    /// Wat er met de gekozen steen kan: waar hij ligt en wat hij raakt.
    func zetkans(_ plaats: Int) -> (vak: String, kans: Zetkans, stichten: Bool)? {
        guard let spel, mensPlaats > 0 else { return nil }
        let t = spel.hand(mensPlaats, plaats)
        guard t != 0 else { return nil }
        let p = Regels.tegelPositie(t)
        let stichten = spel.kanStichten(p.x, p.y) && !spel.teStichten().isEmpty
        return (Regels.naam(p.x, p.y), spel.bekijk(p.x, p.y), stichten)
    }

    var teStichten: [Int] { spel?.teStichten() ?? [] }

    func prijs(_ keten: Int) -> Int { spel?.prijs(keten) ?? 0 }

    /// De steen neerleggen. Raakt hij twee even grote ketens, dan moet de speler
    /// eerst kiezen welke blijft bestaan.
    func leg(plaats: Int, winnaar: Int = 0) {
        guard let spel, let bekeken = zetkans(plaats) else { return }
        if bekeken.kans.gelijkspel && winnaar == 0 {
            fase = .gelijkspel(plaats, bekeken.kans.gelijken)
            return
        }
        guard let verslag = try? spel.leg(speler: mensPlaats, plaats: plaats,
                                          gekozenWinnaar: winnaar) else { return }
        meld(spel.beschrijf(naam: mensNaam, verslag))
        ververs()
        naarKopen()
    }

    func kiesStichten(plaats: Int) {
        guard zetkans(plaats)?.stichten == true else { return }
        fase = .stichten(plaats)
    }

    func sticht(plaats: Int, keten: Int) {
        guard let spel else { return }
        guard let verslag = try? spel.sticht(speler: mensPlaats, plaats: plaats,
                                             keten: keten) else { return }
        meld([Taal.stichtKetenMetAandeel(mensNaam, Regels.ketenLetter(keten),
                                         Regels.naam(verslag.x, verslag.y))])
        ververs()
        naarKopen()
    }

    func pas() {
        guard let spel, case .passen = fase else { return }
        spel.past()
        meld([Taal.kanNiet(mensNaam)])
        ververs()
        volgende()
    }

    // MARK: - kopen

    /// De ketens die bestaan én te betalen zijn.
    var koopbaar: [Ketenstand] {
        guard let spel, mensPlaats > 0 else { return [] }
        let geld = spel.spelers[mensPlaats].geld
        return stand.ketens.filter { $0.bestaat && $0.prijs <= geld }
    }

    /// Hoeveel aandelen van deze keten er te betalen zijn, hoogstens drie.
    func maxAantal(_ keten: Int) -> Int {
        guard let spel, mensPlaats > 0 else { return 0 }
        let prijs = spel.prijs(keten)
        guard prijs > 0 else { return 0 }
        return min(3, spel.spelers[mensPlaats].geld / prijs)
    }

    /// Na het leggen volgt de koopfase. Is er niets te betalen, dan staat er
    /// "er valt niets te kopen" en gaat de beurt met één knop verder.
    private func naarKopen() {
        fase = .kopenKeten
    }

    func kiesKoopketen(_ keten: Int) { fase = .kopenAantal(keten) }

    func terugNaarKetens() { fase = .kopenKeten }

    func koop(keten: Int, aantal: Int) {
        guard let spel else { return }
        let prijs = spel.prijs(keten)
        let n = spel.koop(speler: mensPlaats, keten: keten, aantal: aantal)
        meld([n > 0 ? Taal.koopt(mensNaam, n, Regels.ketenLetter(keten), prijs)
                    : Taal.kooptNiets(mensNaam)])
        ververs()
        volgende()
    }

    func koopNiets() {
        meld([Taal.kooptNiets(mensNaam)])
        volgende()
    }

    // MARK: - meldingen en afdruk

    private func meld(_ regels: [String]) {
        for regel in regels {
            teller += 1
            meldingen.append(Melding(id: teller, tekst: regel))
        }
        // Een partij van 210 beurten levert een paar duizend regels op; zo ver
        // terugkijken doet niemand, en het scherm blijft er licht van.
        if meldingen.count > 600 { meldingen.removeFirst(meldingen.count - 600) }
    }

    /// Een nieuwe afdruk van de spelstand maken.
    private func ververs() {
        guard let spel else { stand = Stand(); return }
        var nieuw = Stand()

        for y in 1...Regels.grootte {
            for x in 1...Regels.grootte {
                nieuw.vakken[Stand.plaats(kolom: x, rij: y)] = spel.vak(x, y)
            }
        }

        nieuw.ketens = (1...Regels.aantalKetens).map { c in
            let rang = spel.rangorde(c)
            let eerste = spel.spelers[rang[0]].aandelen[c] > 0 ? rang[0] : 0
            let tweede = spel.spelers[rang[1]].aandelen[c] > 0 ? rang[1] : 0
            return Ketenstand(nummer: c, letter: Regels.ketenLetter(c),
                              tegels: spel.ketenGrootte(c), prijs: spel.prijs(c),
                              eerste: eerste, tweede: tweede)
        }

        nieuw.spelers = (1...Regels.aantalSpelers).map { q in
            let s = spel.spelers[q]
            return Spelerstand(nummer: q, naam: s.naam, geld: s.geld,
                               vermogen: spel.vermogen(q), aandelen: s.aandelen,
                               mens: s.mens)
        }

        if spel.mensPlaats > 0 {
            let magPlaatsen = Set(spel.geldigePlaatsen(spel.mensPlaats))
            nieuw.hand = (0..<Regels.handGrootte).map { s in
                let t = spel.hand(spel.mensPlaats, s)
                guard t != 0 else {
                    return Handsteen(plaats: s, steen: 0, vak: "", mag: false)
                }
                let p = Regels.tegelPositie(t)
                let plek = Stand.plaats(kolom: p.x, rij: p.y)
                nieuw.eigenSteen[plek] = s + 1
                nieuw.eigenMag[plek] = magPlaatsen.contains(s)
                return Handsteen(plaats: s, steen: t, vak: Regels.naam(p.x, p.y),
                                 mag: magPlaatsen.contains(s))
            }
        }

        nieuw.zak = spel.zak.count
        nieuw.beurt = spel.beurt
        nieuw.aanDeBeurt = spel.aanDeBeurt
        nieuw.klaar = spel.klaar
        nieuw.eindreden = spel.eindreden
        if spel.klaar { nieuw.eindstand = spel.eindstand() }
        stand = nieuw
    }
}
