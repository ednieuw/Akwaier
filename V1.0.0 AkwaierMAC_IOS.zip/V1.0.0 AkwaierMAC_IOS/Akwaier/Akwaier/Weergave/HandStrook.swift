import SwiftUI
import AkwaierKern

/// De acht stenen in de hand, met hun vaknaam. Een steen die je nu nergens
/// kwijt kunt staat gedempt.
struct HandStrook: View {
    let stand: Stand
    let weergave: Weergave
    let gekozen: Int?
    let aanZet: Bool
    let kies: (Int) -> Void

    var body: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(stand.hand) { steen in
                    knop(steen)
                }
            }
            .padding(.horizontal, 2)
            .padding(.vertical, 2)
        }
    }

    private func knop(_ steen: Handsteen) -> some View {
        let isGekozen = gekozen == steen.plaats
        let bruikbaar = aanZet && steen.mag
        return Button {
            kies(steen.plaats)
        } label: {
            VStack(spacing: 1) {
                Text(String(steen.plaats + 1))
                    .font(.caption2.monospacedDigit())
                    .foregroundStyle(weergave.zachteTekst)
                    .frame(maxWidth: .infinity, alignment: .leading)
                Text(steen.steen == 0 ? "-" : steen.vak)
                    .font(.title3.weight(.semibold).monospacedDigit())
                    .foregroundStyle(bruikbaar ? weergave.tekst : weergave.zachteTekst)
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .frame(minWidth: 68)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(bruikbaar ? weergave.eigenSteen : weergave.vlak)
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .strokeBorder(isGekozen ? weergave.keuzekader : weergave.lijn,
                                  lineWidth: isGekozen ? 3 : 1)
            )
        }
        .buttonStyle(.plain)
        .disabled(!bruikbaar)
    }
}
