import SwiftUI
import AkwaierKern

/// Wat iedere speler doet, inclusief de fusies en de bonusuitkeringen. De laatste
/// melding blijft in beeld.
struct MeldingenVak: View {
    let meldingen: [Melding]
    let weergave: Weergave

    var body: some View {
        ScrollViewReader { rol in
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 1) {
                    ForEach(meldingen) { melding in
                        Text(melding.tekst)
                            .font(Maten.log)
                            .foregroundStyle(melding.ingesprongen
                                             ? weergave.zachteTekst : weergave.tekst)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .id(melding.id)
                    }
                }
                .padding(8)
            }
            .background(weergave.vlak)
            .clipShape(RoundedRectangle(cornerRadius: 8))
            .bijVerandering(van: meldingen.count) { _ in
                guard let laatste = meldingen.last else { return }
                withAnimation(.easeOut(duration: 0.15)) {
                    rol.scrollTo(laatste.id, anchor: .bottom)
                }
            }
        }
    }
}
