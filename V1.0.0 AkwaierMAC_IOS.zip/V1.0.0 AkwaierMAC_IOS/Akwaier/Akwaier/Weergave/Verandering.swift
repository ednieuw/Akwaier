import SwiftUI

extension View {
    /// `onChange` dat vanaf iOS 16 en macOS 13 werkt.
    ///
    /// De app draait vanaf iOS 16.6; daar bestaat alleen de oude vorm met één
    /// meegegeven waarde, en die is op nieuwere stelsels juist afgekeurd. Dit
    /// hulpje kiest per stelsel de goede, zodat er nergens een waarschuwing
    /// overblijft.
    @ViewBuilder
    func bijVerandering<W: Equatable>(van waarde: W,
                                      doe actie: @escaping (W) -> Void) -> some View {
        if #available(iOS 17.0, macOS 14.0, *) {
            self.onChange(of: waarde) { _, nieuw in actie(nieuw) }
        } else {
            self.onChange(of: waarde) { nieuw in actie(nieuw) }
        }
    }
}
