import SwiftUI
import AkwaierKern

/// De spelregels, in de taal die in het startvenster gekozen is. De tekst komt
/// uit `Spelregels` in de kern; hier staat alleen hoe hij eruitziet.
struct SpelregelScherm: View {
    let weergave: Weergave
    let sluit: () -> Void

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text(Spelregels.titel)
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(weergave.tekst)
                Spacer()
                Button(Taal.sluiten, action: sluit)
                    .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal, 20)
            .padding(.vertical, 14)

            Divider()

            ScrollView {
                VStack(alignment: .leading, spacing: 18) {
                    Text(Spelregels.inleiding)
                        .foregroundStyle(weergave.tekst)
                    Text(Spelregels.herkomst)
                        .font(.callout)
                        .foregroundStyle(weergave.zachteTekst)

                    ForEach(Array(Spelregels.blokken.enumerated()), id: \.offset) { _, blok in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(blok.kop)
                                .font(.headline)
                                .foregroundStyle(weergave.tekst)
                            ForEach(Array(blok.delen.enumerated()), id: \.offset) { _, deel in
                                onderdeel(deel)
                            }
                        }
                        .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(20)
                .frame(maxWidth: 700, alignment: .leading)
                .frame(maxWidth: .infinity)
            }
        }
        .background(weergave.achtergrond)
        .frame(minWidth: 360, minHeight: 420)
    }

    @ViewBuilder
    private func onderdeel(_ deel: Spelregeldeel) -> some View {
        switch deel {
        case .alinea(let tekst):
            Text(tekst)
                .foregroundStyle(weergave.tekst)
                .fixedSize(horizontal: false, vertical: true)

        case .opsomming(let punten):
            VStack(alignment: .leading, spacing: 6) {
                ForEach(Array(punten.enumerated()), id: \.offset) { _, punt in
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Text("•").foregroundStyle(weergave.zachteTekst)
                        Text(punt)
                            .foregroundStyle(weergave.tekst)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }

        case .tabel(let koppen, let rijen):
            VStack(spacing: 0) {
                Kopbalk(weergave: weergave) {
                    ForEach(Array(koppen.enumerated()), id: \.offset) { nr, kop in
                        Text(kop.uppercased())
                            .frame(maxWidth: .infinity, alignment: nr == 0 ? .leading : .leading)
                    }
                }
                ForEach(Array(rijen.enumerated()), id: \.offset) { nr, rij in
                    HStack(alignment: .top, spacing: 8) {
                        ForEach(Array(rij.enumerated()), id: \.offset) { _, cel in
                            Text(cel)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .font(.callout)
                    .foregroundStyle(weergave.tekst)
                    .padding(.vertical, 4)
                    .padding(.horizontal, 8)
                    .background(nr.isMultiple(of: 2) ? Color.clear : weergave.aanDeBeurtVlak)
                }
            }
            .background(weergave.vlak)
            .clipShape(RoundedRectangle(cornerRadius: 8))
        }
    }
}
