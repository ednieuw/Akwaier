import SwiftUI
import AkwaierKern

/// Het gegevenspaneel: per keten de prijs en het aantal tegels, het aandeelbezit
/// van de zes spelers, en per speler geld en vermogen.
struct PaneelScherm: View {
    let stand: Stand
    let weergave: Weergave
    let mensPlaats: Int

    var body: some View {
        // De drie blokken staan strak op elkaar: op een liggende iPad moeten de
        // acht ketens en alle zes de spelers er samen op passen.
        VStack(alignment: .leading, spacing: 6) {
            ketenblok
            aandeelblok
            spelerblok
        }
    }

    // MARK: - de acht ketens

    private var ketenblok: some View {
        VStack(spacing: 0) {
            Kopbalk(weergave: weergave) {
                Text(Taal.kopKeten).frame(width: Maten.letter, alignment: .leading)
                Text(Taal.kopPrijs).frame(width: Maten.prijs, alignment: .trailing)
                Text(Taal.kopTegels).frame(width: Maten.tegels, alignment: .trailing)
                Text(Taal.kopStatus)
                Spacer()
            }
            ForEach(stand.ketens) { keten in
                HStack(spacing: 8) {
                    Ketentegel(keten: keten.nummer, weergave: weergave, zijde: 18)
                        .frame(width: Maten.letter, alignment: .leading)
                    Text(keten.bestaat ? String(keten.prijs) : "-")
                        .frame(width: Maten.prijs, alignment: .trailing)
                        .monospacedDigit()
                    Text(keten.bestaat ? String(keten.tegels) : "-")
                        .frame(width: Maten.tegels, alignment: .trailing)
                        .monospacedDigit()
                    Text(keten.bestaat ? "" : Taal.teStichten)
                        .foregroundStyle(weergave.zachteTekst)
                        // Op een telefoon is er weinig ruimte; de regel mag krimpen
                        // maar niet afbreken, anders worden de rijen ongelijk hoog.
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Spacer()
                }
                .padding(.vertical, 1)
                .padding(.horizontal, 8)
            }
        }
        .font(Maten.tekst)
        .foregroundStyle(weergave.tekst)
        .background(weergave.vlak)
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    // MARK: - aandelen per speler

    private var aandeelblok: some View {
        VStack(spacing: 0) {
            Kopbalk(weergave: weergave) {
                Text(Taal.kopAandelen)
                Spacer()
            }
            HStack(spacing: 4) {
                Color.clear.frame(width: 26, height: 1)
                ForEach(1...Regels.aantalSpelers, id: \.self) { q in
                    Text(String(q))
                        .frame(maxWidth: .infinity)
                        .foregroundStyle(q == mensPlaats ? weergave.tekst : weergave.zachteTekst)
                        .fontWeight(q == mensPlaats ? .bold : .regular)
                }
            }
            .font(Maten.kolomkop)
            .padding(.horizontal, 8)
            .padding(.top, 2)

            ForEach(stand.ketens) { keten in
                HStack(spacing: 4) {
                    Ketentegel(keten: keten.nummer, weergave: weergave, zijde: 18)
                    ForEach(1...Regels.aantalSpelers, id: \.self) { q in
                        aandeel(keten: keten, speler: q)
                    }
                }
                .padding(.vertical, 1)
                .padding(.horizontal, 8)
            }
            .padding(.bottom, 4)
        }
        .font(Maten.tekst)
        .foregroundStyle(weergave.tekst)
        .background(weergave.vlak)
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }

    /// Alleen de grootste en de op één na grootste aandeelhouder krijgen bij een
    /// fusie geld; daarom zijn juist die twee gemarkeerd.
    private func aandeel(keten: Ketenstand, speler q: Int) -> some View {
        let aantal = stand.spelers.first { $0.nummer == q }?.aandelen[keten.nummer] ?? 0
        let eerste = keten.eerste == q
        let tweede = keten.tweede == q
        return Text(aantal > 0 ? String(aantal) : "·")
            .frame(maxWidth: .infinity)
            .monospacedDigit()
            .fontWeight(eerste ? .bold : .regular)
            .foregroundStyle(aantal == 0 ? weergave.zachteTekst.opacity(0.5)
                             : eerste ? weergave.eersteHouder
                             : tweede ? weergave.tweedeHouder
                             : weergave.tekst)
    }

    // MARK: - geld en vermogen

    private var spelerblok: some View {
        VStack(spacing: 0) {
            Kopbalk(weergave: weergave) {
                Text(Taal.kopSpeler).frame(width: Maten.naam, alignment: .leading)
                Text(Taal.kopGeld).frame(width: Maten.geld, alignment: .trailing)
                Text(Taal.kopVermogen).frame(width: Maten.vermogen, alignment: .trailing)
                Spacer()
            }
            ForEach(stand.spelers) { speler in
                HStack(spacing: 8) {
                    Text("\(speler.nummer) \(speler.naam)\(speler.mens ? Taal.jij : "")")
                        .fontWeight(speler.nummer == stand.aanDeBeurt ? .bold : .regular)
                        .frame(width: Maten.naam, alignment: .leading)
                        .lineLimit(1)
                        .minimumScaleFactor(0.7)
                    Text(String(speler.geld))
                        .frame(width: Maten.geld, alignment: .trailing).monospacedDigit()
                    Text(String(speler.vermogen))
                        .frame(width: Maten.vermogen, alignment: .trailing).monospacedDigit()
                    Spacer()
                }
                .padding(.vertical, 1)
                .padding(.horizontal, 8)
                .background(speler.nummer == stand.aanDeBeurt
                            ? weergave.aanDeBeurtVlak : Color.clear)
            }
        }
        .font(Maten.tekst)
        .foregroundStyle(weergave.tekst)
        .background(weergave.vlak)
        .clipShape(RoundedRectangle(cornerRadius: 8))
    }
}

/// De kolombreedtes van het paneel. Kop en regels gebruiken dezelfde maten,
/// zodat de getallen precies onder hun kop staan; wat overblijft valt rechts weg
/// in plaats van dat de kolommen naar de rand worden geduwd.
enum Maten {
    static let letter: CGFloat = 46
    static let prijs: CGFloat = 62
    static let tegels: CGFloat = 52
    static let naam: CGFloat = 128
    static let geld: CGFloat = 72
    static let vermogen: CGFloat = 82

    // Vaste lettergroottes in plaats van de stijlen van het systeem: het paneel
    // is een tabel die in zijn geheel op het scherm moet passen, en dezelfde
    // stijl valt op de Mac een paar punten kleiner uit dan op de iPad.
    #if os(macOS)
    static let tekst = Font.system(size: 13)
    static let kop = Font.system(size: 11, weight: .semibold)
    static let kolomkop = Font.system(size: 11)
    static let log = Font.system(size: 12, design: .monospaced)
    #else
    static let tekst = Font.system(size: 16)
    static let kop = Font.system(size: 13, weight: .semibold)
    static let kolomkop = Font.system(size: 13)
    static let log = Font.system(size: 14, design: .monospaced)
    #endif
}

/// De kop van een blok, met dezelfde balk als de Windows-versie.
struct Kopbalk<Inhoud: View>: View {
    let weergave: Weergave
    @ViewBuilder let inhoud: Inhoud

    var body: some View {
        HStack(spacing: 8) { inhoud }
            .font(Maten.kop)
            .foregroundStyle(weergave.kopTekst)
            .padding(.vertical, 3)
            .padding(.horizontal, 8)
            .frame(maxWidth: .infinity)
            .background(weergave.kopVlak)
    }
}

/// Het gekleurde blokje met de ketenletter erin.
struct Ketentegel: View {
    let keten: Int
    let weergave: Weergave
    var zijde: CGFloat = 18

    var body: some View {
        let kleur = weergave.tegel(keten)
        RoundedRectangle(cornerRadius: 4)
            .fill(kleur.vlak)
            .frame(width: zijde, height: zijde)
            .overlay(
                Text(String(Regels.ketenLetter(keten)))
                    .font(.system(size: zijde * 0.62, weight: .bold))
                    .foregroundStyle(kleur.inkt)
            )
    }
}
