import SwiftUI
import AkwaierKern

/// Het startvenster: naam, plaats aan tafel, taal, en de keuze meedoen of
/// kijken. In het origineel was dat de vraag "DOE JE MEE MENS ?".
struct StartScherm: View {
    @ObservedObject var model: Spelmodel
    let regels: () -> Void
    let begin: (String, Int, Bool) -> Void

    @State private var naam = Scorelijst.laadNaam()
    @State private var plaats = 0            // 0 = willekeurig
    @State private var engels = Taal.engels

    private var weergave: Weergave { model.weergave }

    var body: some View {
        VStack(alignment: .leading, spacing: 18) {
            VStack(alignment: .leading, spacing: 4) {
                Text(Taal.doeJeMee)
                    .font(.title2.weight(.bold))
                    .foregroundStyle(weergave.tekst)
                Text(Taal.spelenMee)
                    .font(.footnote)
                    .foregroundStyle(weergave.zachteTekst)
            }

            Grid(alignment: .leading, horizontalSpacing: 12, verticalSpacing: 12) {
                GridRow {
                    Text(Taal.labelNaam).foregroundStyle(weergave.zachteTekst)
                    TextField("", text: $naam)
                        .textFieldStyle(.roundedBorder)
                        .frame(minWidth: 180)
                        .onSubmit { start(meedoen: true) }
                }
                GridRow {
                    Text(Taal.labelPlaats).foregroundStyle(weergave.zachteTekst)
                    Picker("", selection: $plaats) {
                        Text(Taal.willekeurig).tag(0)
                        ForEach(1...Regels.aantalSpelers, id: \.self) { nr in
                            Text("\(nr)  \(Taal.spelernamen[nr - 1])").tag(nr)
                        }
                    }
                    .labelsHidden()
                }
                GridRow {
                    Text(Taal.labelTaal).foregroundStyle(weergave.zachteTekst)
                    Picker("", selection: $engels) {
                        Text(Taal.taalNederlands).tag(false)
                        Text(Taal.taalEngels).tag(true)
                    }
                    .labelsHidden()
                    .bijVerandering(van: engels) { nieuw in model.engels = nieuw }
                }
            }

            HStack(spacing: 12) {
                Button(Taal.ikDoeMee) { start(meedoen: true) }
                    .buttonStyle(.borderedProminent)
                Button(Taal.alleenKijken) { start(meedoen: false) }
                    .buttonStyle(.bordered)
                Spacer()
                Button(Taal.spelregels, action: regels)
                    .buttonStyle(.bordered)
            }
            .padding(.top, 4)
        }
        .padding(24)
        .frame(maxWidth: 460)
    }

    private func start(meedoen: Bool) {
        let stoel = plaats == 0 ? Int.random(in: 1...Regels.aantalSpelers) : plaats
        // Wie het veld leegmaakt heet MENS, zoals in het origineel uit 1987.
        // De naam staat al ingevuld, dus dat is een bewuste keuze.
        begin(naam, stoel, meedoen)
    }
}
