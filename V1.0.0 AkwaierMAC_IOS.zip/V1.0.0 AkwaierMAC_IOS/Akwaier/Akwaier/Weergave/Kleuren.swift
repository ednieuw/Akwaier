import SwiftUI
import AkwaierKern

#if canImport(UIKit)
import UIKit
#else
import AppKit
#endif

/// Een kleur die in donkere modus anders is dan in lichte. Op iOS is donkere
/// modus geen keuze van de app, dus elke kleur die het scherm gebruikt heeft
/// hier allebei de waarden staan.
extension Color {
    init(licht: UInt32, donker: UInt32) {
        #if canImport(UIKit)
        self.init(uiColor: UIColor { omgeving in
            omgeving.userInterfaceStyle == .dark
                ? UIColor(rgb: donker) : UIColor(rgb: licht)
        })
        #else
        self.init(nsColor: NSColor(name: nil) { uiterlijk in
            let donkerAan = uiterlijk.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
            return donkerAan ? NSColor(rgb: donker) : NSColor(rgb: licht)
        })
        #endif
    }

    init(rgb: UInt32) {
        self.init(.sRGB,
                  red: Double((rgb >> 16) & 0xFF) / 255,
                  green: Double((rgb >> 8) & 0xFF) / 255,
                  blue: Double(rgb & 0xFF) / 255,
                  opacity: 1)
    }
}

#if canImport(UIKit)
private extension UIColor {
    convenience init(rgb: UInt32) {
        self.init(red: CGFloat((rgb >> 16) & 0xFF) / 255,
                  green: CGFloat((rgb >> 8) & 0xFF) / 255,
                  blue: CGFloat(rgb & 0xFF) / 255,
                  alpha: 1)
    }
}
#else
private extension NSColor {
    convenience init(rgb: UInt32) {
        self.init(srgbRed: CGFloat((rgb >> 16) & 0xFF) / 255,
                  green: CGFloat((rgb >> 8) & 0xFF) / 255,
                  blue: CGFloat(rgb & 0xFF) / 255,
                  alpha: 1)
    }
}
#endif

/// Het vlak van een keten met de kleur van de letter erop.
struct Tegelkleur {
    let vlak: Color
    let inkt: Color
}

/// De twee weergaven van de Windows-versie: rustige kleuren, of die van het
/// BBC Micro-scherm uit `DATA 29000-29007` van het origineel.
enum Weergave: String, CaseIterable, Identifiable {
    case modern
    case retro

    var id: String { rawValue }

    var naam: String { self == .modern ? Taal.weergaveModern : Taal.weergaveRetro }

    /// Retro heeft een zwarte achtergrond, ook als het toestel op licht staat.
    var altijdDonker: Bool { self == .retro }

    /// De acht ketenkleuren, 1 tot en met 8 is A tot en met H.
    ///
    /// Modern: dezelfde kleuren als de Windows-versie, met voor donkere modus een
    /// lichtere tint van dezelfde kleur — anders is er op een donker scherm geen
    /// verschil meer tussen A en de achtergrond.
    /// Retro: de BBC-kleuren. Twee zijn bijgesteld zoals in de Windows-versie:
    /// keten A is donkergrijs in plaats van zuiver zwart, en F krijgt een zwarte
    /// letter.
    func tegel(_ keten: Int) -> Tegelkleur {
        guard (1...Regels.aantalKetens).contains(keten) else {
            return Tegelkleur(vlak: .clear, inkt: .primary)
        }
        switch self {
        case .modern:
            let vlak = Self.modernVlak[keten - 1]
            return Tegelkleur(vlak: Color(licht: vlak.0, donker: vlak.1),
                              inkt: Color(licht: 0xFFFFFF, donker: 0x11181C))
        case .retro:
            let vlak = Self.retroVlak[keten - 1]
            return Tegelkleur(vlak: Color(rgb: vlak.0), inkt: Color(rgb: vlak.1))
        }
    }

    private static let modernVlak: [(UInt32, UInt32)] = [
        (0x455A64, 0x90A4AE),   // A blauwgrijs
        (0x2E7D32, 0x66BB6A),   // B groen
        (0xF9A825, 0xFFCA28),   // C amber
        (0x1565C0, 0x64B5F6),   // D blauw
        (0x8E24AA, 0xBA68C8),   // E paars
        (0x00838F, 0x4DD0E1),   // F cyaan
        (0x5D4037, 0xA1887F),   // G bruin
        (0xC62828, 0xEF5350),   // H rood
    ]

    private static let retroVlak: [(UInt32, UInt32)] = [
        (0x3C3C3C, 0xFFFFFF),   // A zwart, bijgesteld naar donkergrijs
        (0x00CC00, 0x000000),   // B groen
        (0xFFFF00, 0x000000),   // C geel
        (0x0000FF, 0xFFFFFF),   // D blauw
        (0xFF00FF, 0xFFFFFF),   // E magenta
        (0x00FFFF, 0x000000),   // F lichtblauw, zwarte letter
        (0xFFFFFF, 0x000000),   // G wit
        (0xFF0000, 0xFFFFFF),   // H rood
    ]

    // MARK: - de kleuren van het scherm zelf

    var achtergrond: Color {
        self == .retro ? Color(rgb: 0x000000) : Color(licht: 0xF5F7F8, donker: 0x16191B)
    }

    /// Het vlak waar het bord en de panelen op liggen.
    var vlak: Color {
        self == .retro ? Color(rgb: 0x101010) : Color(licht: 0xFFFFFF, donker: 0x1F2426)
    }

    /// Een leeg vakje.
    var leegVak: Color {
        self == .retro ? Color(rgb: 0x000000) : Color(licht: 0xFFFFFF, donker: 0x1F2426)
    }

    /// Een losse steen: wel gelegd, maar hoort bij geen enkele keten.
    var losseSteen: Color {
        self == .retro ? Color(rgb: 0x606060) : Color(licht: 0xCFD8DC, donker: 0x546067)
    }

    /// Het vakje van een steen die de speler zelf in de hand heeft.
    var eigenSteen: Color {
        self == .retro ? Color(rgb: 0x202020) : Color(licht: 0xE3E8EA, donker: 0x2E3639)
    }

    var lijn: Color {
        self == .retro ? Color(rgb: 0x303030) : Color(licht: 0xE0E5E8, donker: 0x2B3134)
    }

    var tekst: Color {
        self == .retro ? Color(rgb: 0xEEEEEE) : Color(licht: 0x11181C, donker: 0xEDF1F3)
    }

    var zachteTekst: Color {
        self == .retro ? Color(rgb: 0x909090) : Color(licht: 0x60717A, donker: 0x9AA7AD)
    }

    /// Het kader om de gekozen steen. Oranje in de moderne weergave, geel in retro.
    var keuzekader: Color {
        self == .retro ? Color(rgb: 0xFFFF00) : Color(licht: 0xE65100, donker: 0xFFA726)
    }

    /// De grootste aandeelhouder.
    var eersteHouder: Color {
        self == .retro ? Color(rgb: 0xFFFF00) : Color(licht: 0xE65100, donker: 0xFFB74D)
    }

    /// De op één na grootste aandeelhouder.
    var tweedeHouder: Color {
        self == .retro ? Color(rgb: 0x00CC00) : Color(licht: 0x8D6E63, donker: 0xBCAAA4)
    }

    /// De kop van een blok in het gegevenspaneel.
    var kopVlak: Color {
        self == .retro ? Color(rgb: 0x202020) : Color(licht: 0x455A64, donker: 0x2E3B42)
    }

    var kopTekst: Color {
        self == .retro ? Color(rgb: 0xFFFFFF) : Color(rgb: 0xFFFFFF)
    }

    /// Het balkje onder de speler die aan de beurt is.
    var aanDeBeurtVlak: Color {
        self == .retro ? Color(rgb: 0x282828) : Color(licht: 0xECEFF1, donker: 0x2B3236)
    }
}
