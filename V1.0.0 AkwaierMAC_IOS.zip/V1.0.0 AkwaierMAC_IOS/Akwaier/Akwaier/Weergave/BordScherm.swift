import SwiftUI
import AkwaierKern

/// Het bord van 15 bij 15. Rijen A tot en met O van boven naar beneden,
/// kolommen 1 tot en met 15: een vakje heet `B7`.
///
/// Het bord is vierkant en rekent zijn vakgrootte uit de ruimte die het krijgt,
/// zodat het op elk scherm past zonder vaste maten.
struct BordScherm: View {
    let stand: Stand
    let weergave: Weergave
    let gekozenVak: Int?
    let tik: (Int, Int) -> Void

    private let n = Regels.grootte

    var body: some View {
        GeometryReader { ruimte in
            let rand = randbreedte(ruimte.size)
            let zijde = min(ruimte.size.width - rand, ruimte.size.height - rand)
            let vak = max(zijde / CGFloat(n), 1)
            let letterMaat = min(max(vak * 0.52, 7), 22)

            VStack(spacing: 0) {
                kolomkop(vak: vak, rand: rand, maat: letterMaat)
                ForEach(1...n, id: \.self) { y in
                    HStack(spacing: 0) {
                        rijkop(y, breedte: rand, hoogte: vak, maat: letterMaat)
                        ForEach(1...n, id: \.self) { x in
                            vakje(kolom: x, rij: y, zijde: vak, maat: letterMaat)
                        }
                        rijkop(y, breedte: rand, hoogte: vak, maat: letterMaat)
                    }
                }
                kolomkop(vak: vak, rand: rand, maat: letterMaat)
            }
            .frame(width: ruimte.size.width, height: ruimte.size.height)
        }
        .aspectRatio(1, contentMode: .fit)
    }

    /// De strook met de rijletters en de kolomnummers eromheen.
    private func randbreedte(_ maat: CGSize) -> CGFloat {
        min(maat.width, maat.height) * 0.09
    }

    private func kolomkop(vak: CGFloat, rand: CGFloat, maat: CGFloat) -> some View {
        HStack(spacing: 0) {
            Color.clear.frame(width: rand, height: rand / 2)
            ForEach(1...n, id: \.self) { x in
                Text(kolomnaam(x))
                    .font(.system(size: maat * 0.8).monospacedDigit())
                    .foregroundStyle(weergave.zachteTekst)
                    .frame(width: vak, height: rand / 2)
            }
            Color.clear.frame(width: rand, height: rand / 2)
        }
    }

    /// In de retro-weergave staat de kolomkop er net als toen als 123456789012345.
    private func kolomnaam(_ x: Int) -> String {
        weergave == .retro ? String(x % 10) : String(x)
    }

    private func rijkop(_ y: Int, breedte: CGFloat, hoogte: CGFloat, maat: CGFloat) -> some View {
        Text(String(Character(UnicodeScalar(UInt8(65 + y - 1)))))
            .font(.system(size: maat * 0.8))
            .foregroundStyle(weergave.zachteTekst)
            .frame(width: breedte, height: hoogte)
    }

    private func vakje(kolom x: Int, rij y: Int, zijde: CGFloat, maat: CGFloat) -> some View {
        let plek = Stand.plaats(kolom: x, rij: y)
        let inhoud = stand.vakken[plek]
        let eigen = stand.eigenSteen[plek]
        let gekozen = gekozenVak == plek

        return ZStack {
            RoundedRectangle(cornerRadius: zijde * 0.14)
                .fill(vulling(inhoud: inhoud, eigen: eigen, mag: stand.eigenMag[plek]))
                .padding(zijde * 0.055)
            if inhoud >= 1 {
                Text(String(Regels.ketenLetter(inhoud)))
                    .font(.system(size: maat, weight: .bold))
                    .foregroundStyle(weergave.tegel(inhoud).inkt)
            } else if eigen > 0 {
                Text(String(eigen))
                    .font(.system(size: maat, weight: .bold).monospacedDigit())
                    .foregroundStyle(stand.eigenMag[plek] ? weergave.tekst : weergave.zachteTekst)
            } else if inhoud == Regels.leeg {
                Circle()
                    .fill(weergave.zachteTekst.opacity(0.35))
                    .frame(width: max(zijde * 0.08, 1), height: max(zijde * 0.08, 1))
            }
            if gekozen {
                RoundedRectangle(cornerRadius: zijde * 0.14)
                    .strokeBorder(weergave.keuzekader, lineWidth: max(zijde * 0.09, 1.5))
                    .padding(zijde * 0.055)
            }
        }
        .frame(width: zijde, height: zijde)
        .background(weergave.lijn.opacity(0.35))
        .contentShape(Rectangle())
        .onTapGesture { tik(x, y) }
        .accessibilityLabel(Regels.naam(x, y))
    }

    private func vulling(inhoud: Int, eigen: Int, mag: Bool) -> Color {
        if inhoud >= 1 { return weergave.tegel(inhoud).vlak }
        if inhoud == Regels.los { return weergave.losseSteen }
        if eigen > 0 { return mag ? weergave.eigenSteen : weergave.leegVak }
        return weergave.leegVak
    }
}
