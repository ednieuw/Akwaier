import SwiftUI

/// Zet wat er in zit naast elkaar en begint een nieuwe regel zodra het niet meer
/// past. De knoppenstrook heeft dat nodig: op een Mac staat alles op één regel,
/// op een telefoon in staande stand op drie.
struct Stroomindeling: Layout {
    var horizontaal: CGFloat = 8
    var verticaal: CGFloat = 8

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let breedte = proposal.width ?? .infinity
        let regels = verdeel(subviews, breedte: breedte)
        let hoogte = regels.reduce(0) { $0 + $1.hoogte } +
            verticaal * CGFloat(max(regels.count - 1, 0))
        let gebruikt = regels.map(\.breedte).max() ?? 0
        return CGSize(width: min(gebruikt, breedte == .infinity ? gebruikt : breedte),
                      height: hoogte)
    }

    func placeSubviews(in vlak: CGRect, proposal: ProposedViewSize,
                       subviews: Subviews, cache: inout ()) {
        let regels = verdeel(subviews, breedte: vlak.width)
        var y = vlak.minY
        for regel in regels {
            var x = vlak.minX
            for i in regel.leden {
                let maat = subviews[i].sizeThatFits(.unspecified)
                subviews[i].place(at: CGPoint(x: x, y: y + (regel.hoogte - maat.height) / 2),
                                  proposal: ProposedViewSize(maat))
                x += maat.width + horizontaal
            }
            y += regel.hoogte + verticaal
        }
    }

    private struct Regel {
        var leden: [Int] = []
        var breedte: CGFloat = 0
        var hoogte: CGFloat = 0
    }

    private func verdeel(_ subviews: Subviews, breedte: CGFloat) -> [Regel] {
        var regels: [Regel] = []
        var huidig = Regel()
        for i in subviews.indices {
            let maat = subviews[i].sizeThatFits(.unspecified)
            let nieuweBreedte = huidig.leden.isEmpty
                ? maat.width : huidig.breedte + horizontaal + maat.width
            if !huidig.leden.isEmpty && nieuweBreedte > breedte {
                regels.append(huidig)
                huidig = Regel(leden: [i], breedte: maat.width, hoogte: maat.height)
            } else {
                huidig.leden.append(i)
                huidig.breedte = nieuweBreedte
                huidig.hoogte = max(huidig.hoogte, maat.height)
            }
        }
        if !huidig.leden.isEmpty { regels.append(huidig) }
        return regels
    }
}
