import SwiftUI
import AkwaierKern

/// De strook onder het bord verandert mee met wat er van de speler gevraagd
/// wordt: kies een steen, leg hem neer of sticht, kies bij gelijkspel de keten
/// die blijft, en koop daarna hoogstens drie aandelen.
struct KnoppenStrook: View {
    @ObservedObject var model: Spelmodel

    private var weergave: Weergave { model.weergave }

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            switch model.fase {
            case .start, .computerSpeelt, .klaar:
                uitleg(model.kijkt ? Taal.kijkmodus : Taal.kiesEenSteenKort)
                    .opacity(model.kijkt ? 1 : 0.35)
            case .kiezen:
                uitleg(Taal.kiesEenSteen)
            case .gekozen(let plaats):
                gekozenStrook(plaats)
            case .stichten(let plaats):
                stichtStrook(plaats)
            case .gelijkspel(let plaats, let ketens):
                gelijkspelStrook(plaats, ketens)
            case .passen:
                uitleg(Taal.geenSteenKwijt)
                Stroomindeling {
                    Button(Taal.pasDezeBeurt) { model.pas() }
                        .buttonStyle(.borderedProminent)
                }
            case .kopenKeten:
                koopStrook()
            case .kopenAantal(let keten):
                aantalStrook(keten)
            }
        }
        .animation(.easeInOut(duration: 0.15), value: model.fase)
    }

    // MARK: - de onderdelen

    private func uitleg(_ tekst: String) -> some View {
        Text(tekst)
            .font(.callout)
            .foregroundStyle(weergave.zachteTekst)
    }

    private func gekozenStrook(_ plaats: Int) -> some View {
        let bekeken = model.zetkans(plaats)
        return VStack(alignment: .leading, spacing: 8) {
            uitleg(Taal.steenIs(plaats + 1, bekeken?.vak ?? ""))
            Stroomindeling {
                if let bekeken {
                    if bekeken.kans.mag {
                        Button(bekeken.kans.winnaar > 0
                               ? Taal.legBij(bekeken.vak, Regels.ketenLetter(bekeken.kans.winnaar))
                               : Taal.legLos(bekeken.vak)) {
                            model.leg(plaats: plaats)
                        }
                        .buttonStyle(.borderedProminent)
                    } else {
                        Text(Taal.magHierNiet)
                            .font(.callout)
                            .foregroundStyle(weergave.eersteHouder)
                    }
                    if bekeken.stichten {
                        Button(Taal.stichtOp(bekeken.vak)) {
                            model.kiesStichten(plaats: plaats)
                        }
                        .buttonStyle(.bordered)
                    }
                }
                Button(Taal.annuleer) { model.annuleer() }
                    .buttonStyle(.bordered)
            }
        }
    }

    private func stichtStrook(_ plaats: Int) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            uitleg(Taal.welkeKetenStichten)
            Stroomindeling {
                ForEach(model.teStichten, id: \.self) { keten in
                    Button { model.sticht(plaats: plaats, keten: keten) } label: {
                        Ketentegel(keten: keten, weergave: weergave, zijde: 34)
                    }
                    .buttonStyle(.plain)
                }
                Button(Taal.annuleer) { model.annuleer() }
                    .buttonStyle(.bordered)
            }
        }
    }

    private func gelijkspelStrook(_ plaats: Int, _ ketens: [Int]) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            uitleg(Taal.welkeBlijft)
            Stroomindeling {
                ForEach(ketens, id: \.self) { keten in
                    Button { model.leg(plaats: plaats, winnaar: keten) } label: {
                        Ketentegel(keten: keten, weergave: weergave, zijde: 34)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func koopStrook() -> some View {
        let koopbaar = model.koopbaar
        return VStack(alignment: .leading, spacing: 8) {
            uitleg(koopbaar.isEmpty ? Taal.nietsTeKopen : Taal.koopHoogstensDrie)
            Stroomindeling {
                if koopbaar.isEmpty {
                    Button(Taal.verder) { model.koopNiets() }
                        .buttonStyle(.borderedProminent)
                } else {
                    ForEach(koopbaar) { keten in
                        Button { model.kiesKoopketen(keten.nummer) } label: {
                            HStack(spacing: 6) {
                                Ketentegel(keten: keten.nummer, weergave: weergave, zijde: 24)
                                Text(String(keten.prijs)).monospacedDigit()
                            }
                        }
                        .buttonStyle(.bordered)
                    }
                    Button(Taal.koopNiets) { model.koopNiets() }
                        .buttonStyle(.bordered)
                }
            }
        }
    }

    private func aantalStrook(_ keten: Int) -> some View {
        let prijs = model.prijs(keten)
        let hoogste = model.maxAantal(keten)
        return VStack(alignment: .leading, spacing: 8) {
            uitleg(Taal.hoeveelVan(Regels.ketenLetter(keten), prijs))
            Stroomindeling {
                if hoogste >= 1 {
                    ForEach(1...hoogste, id: \.self) { aantal in
                        Button {
                            model.koop(keten: keten, aantal: aantal)
                        } label: {
                            Text(String(aantal)).monospacedDigit().frame(minWidth: 22)
                        }
                        .buttonStyle(.borderedProminent)
                    }
                }
                Button(Taal.terug) { model.terugNaarKetens() }
                    .buttonStyle(.bordered)
            }
        }
    }
}
