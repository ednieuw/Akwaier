import SwiftUI
import AkwaierKern

/// Het hele scherm van de app: het startvenster, of een lopende partij.
///
/// De indeling hangt af van de ruimte, niet van het toestel. Is er breedte
/// genoeg, dan staat het bord links en het gegevenspaneel rechts, zoals op de
/// Mac en op een liggende iPad. Anders staat er onder het bord een keuze tussen
/// bord, gegevens en meldingen, en blijven de hand en de knoppen altijd staan.
struct HoofdScherm: View {
    @StateObject private var model = Spelmodel()
    @State private var toonScores = false
    @State private var toonRegels = false
    @State private var deel: Deel = .bord

    enum Deel: String, CaseIterable, Identifiable {
        case bord, paneel, meldingen
        var id: String { rawValue }
        var naam: String {
            switch self {
            case .bord: Taal.tabBord
            case .paneel: Taal.tabPaneel
            case .meldingen: Taal.tabMeldingen
            }
        }
    }

    private var weergave: Weergave { model.weergave }

    var body: some View {
        GeometryReader { ruimte in
            // Naast elkaar alleen als er breedte én hoogte genoeg is. Het paneel
            // is 597 punten hoog - acht ketens, acht rijen aandelen en zes
            // spelers - en daar moet het meldingenvak nog onder. Bij minder dan
            // 800 punten hoogte is het bord met de keuzeknop eronder beter af.
            let breed = ruimte.size.width >= 900 && ruimte.size.height >= 800
                && ruimte.size.width > ruimte.size.height * 0.9
            ZStack {
                weergave.achtergrond.ignoresSafeArea()
                if model.loopt {
                    partij(breed: breed, hoogte: ruimte.size.height)
                } else {
                    StartScherm(model: model,
                                regels: { toonRegels = true }) { naam, plaats, meedoen in
                        model.nieuwSpel(naam: naam, plaats: plaats, meedoen: meedoen)
                    }
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                }
            }
        }
        .preferredColorScheme(weergave.altijdDonker ? .dark : nil)
        .id(model.taalversie)
        .sheet(isPresented: $toonScores) {
            ScoreScherm(weergave: weergave) { toonScores = false }
                .background(weergave.achtergrond)
        }
        .sheet(isPresented: $toonRegels) {
            SpelregelScherm(weergave: weergave) { toonRegels = false }
        }
        .overlay {
            if case .klaar = model.fase { eindvenster }
        }
    }

    // MARK: - een lopende partij

    private func partij(breed: Bool, hoogte: CGFloat) -> some View {
        VStack(spacing: 10) {
            kopstrook
            if breed {
                HStack(alignment: .top, spacing: 14) {
                    VStack(spacing: 10) {
                        BordScherm(stand: model.stand, weergave: weergave,
                                   gekozenVak: gekozenVak) { x, y in
                            model.kiesVak(kolom: x, rij: y)
                        }
                        onderhet
                    }
                    // De vier blokken horen bij elkaar: keten, aandelen, spelers
                    // en daaronder het meldingenvak. Het paneel krijgt eerst de
                    // hoogte die het nodig heeft; het meldingenvak sluit er strak
                    // op aan en loopt door tot onder in het venster.
                    VStack(spacing: 6) {
                        // Op ware hoogte: het paneel mag nooit ingedrukt worden,
                        // anders vallen er ketens of spelers weg.
                        PaneelScherm(stand: model.stand, weergave: weergave,
                                     mensPlaats: model.mensPlaats)
                            .fixedSize(horizontal: false, vertical: true)
                        MeldingenVak(meldingen: model.meldingen, weergave: weergave)
                            .frame(minHeight: 60)
                    }
                    .frame(width: 450)
                    .clipped()
                }
            } else {
                Picker("", selection: $deel) {
                    ForEach(Deel.allCases) { d in Text(d.naam).tag(d) }
                }
                .pickerStyle(.segmented)
                .labelsHidden()

                switch deel {
                case .bord:
                    BordScherm(stand: model.stand, weergave: weergave,
                               gekozenVak: gekozenVak) { x, y in
                        model.kiesVak(kolom: x, rij: y)
                    }
                    .frame(maxHeight: .infinity)
                case .paneel:
                    ScrollView {
                        PaneelScherm(stand: model.stand, weergave: weergave,
                                     mensPlaats: model.mensPlaats)
                    }
                case .meldingen:
                    MeldingenVak(meldingen: model.meldingen, weergave: weergave)
                }
                onderhet
            }
        }
        .padding(12)
    }

    /// De hand en de knoppenstrook staan altijd onder het bord.
    private var onderhet: some View {
        VStack(alignment: .leading, spacing: 8) {
            if model.kijkt {
                Text(Taal.kijkmodusGeenStenen)
                    .font(.footnote)
                    .foregroundStyle(weergave.zachteTekst)
            } else {
                Text(Taal.stenenVan(model.mensNaam))
                    .font(.footnote)
                    .foregroundStyle(weergave.zachteTekst)
                HandStrook(stand: model.stand, weergave: weergave,
                           gekozen: gekozenPlaats, aanZet: aanZet) { plaats in
                    model.kies(plaats: plaats)
                }
            }
            KnoppenStrook(model: model)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var kopstrook: some View {
        Stroomindeling(horizontaal: 10, verticaal: 6) {
            Button(Taal.nieuwSpel) { model.naarStart() }
                .buttonStyle(.bordered)
            Button(Taal.scorelijst) { toonScores = true }
                .buttonStyle(.bordered)
            Button(Taal.spelregels) { toonRegels = true }
                .buttonStyle(.bordered)
            Toggle(Taal.snelSpelen, isOn: Binding(get: { model.snel },
                                                  set: { model.snel = $0 }))
                .toggleStyle(.switch)
                .font(.callout)
                .foregroundStyle(weergave.tekst)
            Menu(Taal.weergave(weergave.naam)) {
                ForEach(Weergave.allCases) { w in
                    Button(w.naam) { model.weergave = w }
                }
            }
            .menuStyle(.borderlessButton)
            .fixedSize()
            Text(kopregel)
                .font(.headline)
                .foregroundStyle(weergave.tekst)
            Text(Taal.stenenInDeZak(model.stand.zak))
                .font(.footnote)
                .foregroundStyle(weergave.zachteTekst)
        }
        // De strook vult de hele breedte en begint links. Anders schuift hij mee
        // met de lengte van de spelersnaam in de beurtregel, en verspringt de
        // schakelaar "snel spelen" bij elke beurt.
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var kopregel: String {
        if model.stand.klaar { return Taal.spelAfgelopenMet(model.stand.eindreden) }
        let nr = model.stand.aanDeBeurt
        let naam = model.stand.spelers.first { $0.nummer == nr }?.naam ?? ""
        return Taal.beurtVan(model.stand.beurt, Regels.maxBeurten, naam)
    }

    // MARK: - de eindstand

    private var eindvenster: some View {
        ZStack {
            Color.black.opacity(0.45).ignoresSafeArea()
            VStack(alignment: .leading, spacing: 12) {
                Text(Taal.spelAfgelopenMet(model.stand.eindreden))
                    .font(.title3.weight(.semibold))
                    .foregroundStyle(weergave.tekst)
                Text(Taal.eindstand)
                    .font(.footnote)
                    .foregroundStyle(weergave.zachteTekst)
                ForEach(Array(model.stand.eindstand.enumerated()), id: \.offset) { nr, regel in
                    HStack {
                        Text("\(nr + 1)  \(regel.naam)")
                            .fontWeight(regel.nummer == model.mensPlaats ? .bold : .regular)
                        Spacer()
                        Text(String(regel.vermogen)).monospacedDigit()
                    }
                    .foregroundStyle(weergave.tekst)
                }
                HStack {
                    Button(Taal.nieuwSpel) { model.naarStart() }
                        .buttonStyle(.borderedProminent)
                    Button(Taal.scorelijst) { toonScores = true }
                        .buttonStyle(.bordered)
                }
                .padding(.top, 6)
            }
            .padding(22)
            .frame(maxWidth: 420)
            .background(weergave.vlak)
            .clipShape(RoundedRectangle(cornerRadius: 14))
            .shadow(radius: 20)
            .padding(20)
        }
    }

    // MARK: - wat er gekozen is

    private var gekozenPlaats: Int? {
        switch model.fase {
        case .gekozen(let p), .stichten(let p), .gelijkspel(let p, _): p
        default: nil
        }
    }

    private var gekozenVak: Int? {
        guard let plaats = gekozenPlaats,
              let steen = model.stand.hand.first(where: { $0.plaats == plaats })?.steen,
              steen != 0 else { return nil }
        let p = Regels.tegelPositie(steen)
        return Stand.plaats(kolom: p.x, rij: p.y)
    }

    private var aanZet: Bool {
        if case .kiezen = model.fase { return true }
        if case .gekozen = model.fase { return true }
        return false
    }
}
