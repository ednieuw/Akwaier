import SwiftUI
import AkwaierKern

/// De dertig hoogste vermogens, de opvolger van het bestand SCORE uit 1987.
struct ScoreScherm: View {
    let weergave: Weergave
    let sluit: () -> Void

    @State private var regels: [Scoreregel] = []

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(Taal.scorelijst)
                .font(.title3.weight(.semibold))
                .foregroundStyle(weergave.tekst)
            Text(Taal.scoreKop)
                .font(.system(.footnote, design: .monospaced))
                .foregroundStyle(weergave.zachteTekst)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 2) {
                    if regels.isEmpty {
                        Text(Taal.nogGeenScores)
                            .font(.system(.body, design: .monospaced))
                            .foregroundStyle(weergave.zachteTekst)
                    }
                    ForEach(Array(regels.enumerated()), id: \.offset) { nr, regel in
                        Text(rij(nr + 1, regel))
                            .font(.system(.body, design: .monospaced))
                            .foregroundStyle(weergave.tekst)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }
            Button(Taal.sluiten, action: sluit)
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity, alignment: .trailing)
        }
        .padding(20)
        .frame(minWidth: 320, minHeight: 380)
        .onAppear { regels = Scorelijst.lees().scores }
    }

    private func rij(_ nr: Int, _ regel: Scoreregel) -> String {
        let nummer = String(nr).leftPad(3)
        let naam = regel.naam.rightPad(12)
        let vermogen = String(regel.vermogen).leftPad(9)
        return "\(nummer)  \(naam)\(vermogen)"
    }
}

private extension String {
    func leftPad(_ n: Int) -> String {
        count >= n ? self : String(repeating: " ", count: n - count) + self
    }
    func rightPad(_ n: Int) -> String {
        count >= n ? self : self + String(repeating: " ", count: n - count)
    }
}
