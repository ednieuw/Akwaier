import SwiftUI
import AkwaierKern

/// Akwaier, naar het BBC Micro-spel AQUIRE.BBC uit 1987.
///
/// De spelregels staan in de package `AkwaierKern` en weten niets van SwiftUI;
/// dit is alleen het scherm.
@main
struct AkwaierApp: App {
    var body: some Scene {
        WindowGroup {
            HoofdScherm()
        }
        #if os(macOS)
        .defaultSize(width: 1180, height: 900)
        #endif
    }
}
