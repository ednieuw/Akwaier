#!/bin/bash
#
# Bouwt Akwaier voor de Mac en zet er een schijfkopie van neer in ../AkwaierDMG.
# Draaien vanuit de projectmap (waar Akwaier.xcodeproj staat):
#
#     Gereedschap/maak-dmg.sh
#
# Wil je hem weggeven, lees dan eerst het stuk over ondertekenen onderaan.

set -euo pipefail

hier="$(cd "$(dirname "$0")/.." && pwd)"
uit="$(cd "$hier/.." && pwd)/AkwaierDMG"

# Buiten de projectmap bouwen: die staat in iCloud-Documents, en de
# synchronisatie zet daar kenmerken op elk bestand dat er verschijnt. Codesign
# weigert een pakket met zulke kenmerken: "resource fork, Finder information,
# or similar detritus not allowed".
bouw="${TMPDIR:-/tmp}/akwaier-dmg"

versie=$(/usr/libexec/PlistBuddy -c "Print :MARKETING_VERSION" /dev/stdin 2>/dev/null <<< "" || true)
versie=${versie:-$(grep -m1 'MARKETING_VERSION' "$hier/Akwaier.xcodeproj/project.pbxproj" | sed 's/.*= *//; s/;.*//')}

# Is er een Developer ID-certificaat, dan daarmee ondertekenen: dat is het
# certificaat waarmee je de app mag weggeven. Anders laat Xcode zijn gang gaan
# en wordt het het ontwikkelcertificaat.
if security find-identity -v -p codesigning | grep -q "Developer ID Application"; then
    echo "==> Developer ID gevonden, daarmee ondertekenen"
    tekenen=(CODE_SIGN_STYLE=Manual
             CODE_SIGN_IDENTITY="Developer ID Application"
             DEVELOPMENT_TEAM=U533G62Q3B
             OTHER_CODE_SIGN_FLAGS=--timestamp)
else
    tekenen=()
fi

echo "==> Akwaier $versie bouwen (Release, universeel)"
rm -rf "$bouw"
xcodebuild -project "$hier/Akwaier.xcodeproj" -scheme Akwaier \
           -destination 'platform=macOS' -configuration Release \
           -derivedDataPath "$bouw" ${tekenen[@]+"${tekenen[@]}"} build > "$bouw.log" 2>&1 || {
    echo "bouwen mislukt; zie $bouw.log"; exit 1; }

app="$bouw/Build/Products/Release/Akwaier.app"
[ -d "$app" ] || { echo "Akwaier.app niet gevonden"; exit 1; }

echo "==> schijfkopie samenstellen"
mkdir -p "$uit"
tafel="$bouw/tafel"
rm -rf "$tafel"; mkdir -p "$tafel"
cp -R "$app" "$tafel/"
ln -s /Applications "$tafel/Applications"

kopie="$bouw/Akwaier-$versie.dmg"
hdiutil create -volname "Akwaier $versie" -srcfolder "$tafel" \
               -ov -format UDZO -quiet "$kopie"

# De schijfkopie mee ondertekenen met hetzelfde certificaat als de app.
naam=$(codesign -dv "$app" 2>&1 | sed -n 's/^Authority=\(Apple Development.*\|Developer ID Application.*\)$/\1/p' | head -1)
if [ -n "$naam" ]; then
    codesign --force --sign "$naam" "$kopie"
    echo "==> ondertekend met: $naam"
fi

mkdir -p "$uit"
schijf="$uit/Akwaier-$versie.dmg"
rm -f "$schijf"
mv "$kopie" "$schijf"
rm -rf "$bouw" "$bouw.log"
echo
echo "Klaar: $schijf"
echo
case "$naam" in
  "Developer ID Application"*)
    echo "Dit certificaat is goed om weg te geven. Notariseren doe je met:"
    echo "  xcrun notarytool submit \"$schijf\" --keychain-profile <profiel> --wait"
    echo "  xcrun stapler staple \"$schijf\""
    ;;
  *)
    echo "Let op: ondertekend met een ontwikkelcertificaat. Op je eigen Mac werkt"
    echo "dat, maar op andermans Mac houdt Gatekeeper hem tegen. Voor weggeven heb"
    echo "je een 'Developer ID Application'-certificaat nodig (Xcode > Settings >"
    echo "Accounts > Manage Certificates > +) en daarna notariseren."
    ;;
esac
