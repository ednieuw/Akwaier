#!/usr/bin/env swift
//
//  Tekent het pictogram van Akwaier: een uitsnede van het bord in de Retro
//  BBC-weergave, uit een partij die bijna uitgespeeld is.
//
//  Draaien vanuit de projectmap:
//
//      swift Gereedschap/MaakPictogram.swift
//
//  De uitsnede hieronder komt uit een echte partij: zaad 4, beurt 120 van de zes
//  computerspelers, rij C tot en met F, kolom 4 tot en met 7. Twee tegels van
//  keten C, een blok van vier van keten G, een losse steen, en in de onderhoek
//  F en H. Vijf van de acht ketens dus, en een steen die nog nergens bij hoort.
//
//  De kleuren zijn dezelfde als in `Weergave/Kleuren.swift`, weergave retro.
//  Ze staan hier apart omdat dit scriptje los van de app draait.

import AppKit

let uitsnede = [
    "C.GG",
    "C.GG",
    ".o..",
    "F..H",
]

let vlakken: [Character: (vlak: NSColor, inkt: NSColor)] = [
    "A": (kleur(0x3C3C3C), kleur(0xFFFFFF)),
    "B": (kleur(0x00CC00), kleur(0x000000)),
    "C": (kleur(0xFFFF00), kleur(0x000000)),
    "D": (kleur(0x0000FF), kleur(0xFFFFFF)),
    "E": (kleur(0xFF00FF), kleur(0xFFFFFF)),
    "F": (kleur(0x00FFFF), kleur(0x000000)),
    "G": (kleur(0xFFFFFF), kleur(0x000000)),
    "H": (kleur(0xFF0000), kleur(0xFFFFFF)),
]

let achtergrond = kleur(0x000000)
let losseSteen = kleur(0x606060)
let stipje = kleur(0x3A3A3A)

func kleur(_ rgb: UInt32) -> NSColor {
    NSColor(srgbRed: CGFloat((rgb >> 16) & 0xFF) / 255,
            green: CGFloat((rgb >> 8) & 0xFF) / 255,
            blue: CGFloat(rgb & 0xFF) / 255,
            alpha: 1)
}

/// Tekent het pictogram op `maat` bij `maat` beeldpunten.
///
/// - Parameters:
///   - rond: afgeronde hoeken met een doorzichtige rand eromheen. Zo hoort een
///     Mac-pictogram; iOS knipt de vorm zelf uit en wil geen doorzichtigheid.
///   - marge: hoeveel van de zijde als lege rand vrij blijft.
///
/// Zonder ronde hoeken komt er ook geen alfakanaal in het bestand. Dat is geen
/// bijzaak: App Store Connect weigert een iOS-pictogram waar een alfakanaal in
/// zit, ook als het beeld overal dicht is.
func teken(maat: Int, rond: Bool, marge: CGFloat) -> NSBitmapImageRep {
    let beeld = NSBitmapImageRep(bitmapDataPlanes: nil,
                                 pixelsWide: maat, pixelsHigh: maat,
                                 bitsPerSample: 8,
                                 samplesPerPixel: rond ? 4 : 3,
                                 hasAlpha: rond, isPlanar: false,
                                 colorSpaceName: .deviceRGB,
                                 bytesPerRow: 0, bitsPerPixel: 0)!
    NSGraphicsContext.saveGraphicsState()
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep: beeld)

    let zijde = CGFloat(maat)
    let rand = zijde * marge
    let vlak = NSRect(x: rand, y: rand, width: zijde - 2 * rand, height: zijde - 2 * rand)

    achtergrond.setFill()
    if rond {
        NSBezierPath(roundedRect: vlak, xRadius: vlak.width * 0.22,
                     yRadius: vlak.width * 0.22).fill()
    } else {
        NSBezierPath(rect: vlak).fill()
    }

    let n = uitsnede.count
    let hok = vlak.width / CGFloat(n)
    let tegel = hok * 0.86
    let ronding = tegel * 0.16

    for (rij, regel) in uitsnede.enumerated() {
        for (kolom, teken) in regel.enumerated() {
            // Beeldpunten tellen op de Mac van onderaf; het bord van bovenaf.
            let midden = CGPoint(x: vlak.minX + (CGFloat(kolom) + 0.5) * hok,
                                 y: vlak.maxY - (CGFloat(rij) + 0.5) * hok)
            let vakje = NSRect(x: midden.x - tegel / 2, y: midden.y - tegel / 2,
                               width: tegel, height: tegel)

            if let kleuren = vlakken[teken] {
                kleuren.vlak.setFill()
                NSBezierPath(roundedRect: vakje, xRadius: ronding, yRadius: ronding).fill()
                zetLetter(teken, in: vakje, kleur: kleuren.inkt)
            } else if teken == "o" {
                losseSteen.setFill()
                NSBezierPath(roundedRect: vakje, xRadius: ronding, yRadius: ronding).fill()
            } else {
                stipje.setFill()
                let punt = max(hok * 0.08, 1)
                NSBezierPath(ovalIn: NSRect(x: midden.x - punt / 2, y: midden.y - punt / 2,
                                            width: punt, height: punt)).fill()
            }
        }
    }

    NSGraphicsContext.restoreGraphicsState()
    return beeld
}

func zetLetter(_ letter: Character, in vakje: NSRect, kleur: NSColor) {
    let grootte = vakje.height * 0.66
    let opmaak: [NSAttributedString.Key: Any] = [
        .font: NSFont.systemFont(ofSize: grootte, weight: .bold),
        .foregroundColor: kleur,
    ]
    let tekst = NSAttributedString(string: String(letter), attributes: opmaak)
    let maat = tekst.size()
    tekst.draw(at: NSPoint(x: vakje.midX - maat.width / 2,
                           y: vakje.midY - maat.height / 2))
}

func schrijf(_ beeld: NSBitmapImageRep, naar pad: URL) {
    guard let data = beeld.representation(using: .png, properties: [:]) else { return }
    try? data.write(to: pad)
}

// MARK: - schrijven

let hier = URL(fileURLWithPath: CommandLine.arguments.count > 1
               ? CommandLine.arguments[1]
               : FileManager.default.currentDirectoryPath)
let doel = hier.appendingPathComponent("Akwaier/Assets.xcassets/AppIcon.appiconset")
try? FileManager.default.createDirectory(at: doel, withIntermediateDirectories: true)

// iOS en iPadOS: dicht en vierkant, het toestel knipt zelf de hoeken eraf.
schrijf(teken(maat: 1024, rond: false, marge: 0),
        naar: doel.appendingPathComponent("akwaier-1024.png"))
print("akwaier-1024.png geschreven (iOS en iPadOS)")

// De Mac brengt zijn eigen vorm mee, met een rand eromheen.
for maat in [16, 32, 64, 128, 256, 512, 1024] {
    schrijf(teken(maat: maat, rond: true, marge: 0.10),
            naar: doel.appendingPathComponent("akwaier-mac-\(maat).png"))
}
print("akwaier-mac-16 t/m 1024.png geschreven (Mac)")
