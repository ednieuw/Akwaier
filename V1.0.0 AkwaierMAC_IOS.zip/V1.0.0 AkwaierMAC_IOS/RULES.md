# The rules of Akwaier

A game for six players, one of whom is you. In turn you place a tile on a board of 15 by 15. Eight hotel chains grow on it, and you earn money by buying shares in time in the chain that another player is about to swallow. Whoever has the largest net worth at the end wins.

The game was originally programmed in a Acorn BBC Basic program in 1987 and translated in Swift programming language. 

## The board

Rows are named A to O from top to bottom, columns 1 to 15 from left to right. So a square is called B7: row B, column 7 — the letter first, then the number.

There are 225 tiles, one for every square. Everyone holds eight and draws a new one from the bag after each move. Once the bag is empty, your hand slowly runs out.

| what you see | what it is |
|---|---|
| small dot | empty square |
| grey block | a single tile, belonging to no chain |
| coloured square with a letter | a tile of chain A to H |
| number 1 to 8 | one of your eight tiles |
| orange frame | the tile you have picked |


## A turn

- Pick a tile: tap your hand, or the numbered square on the board.
- Place it, or found a chain with it.
- If it touches two chains of equal size, choose which one survives.
- Then buy at most three shares in one chain, or buy nothing.

If you cannot place a single tile, you pass, and you do not buy that turn either.


## Founding

You can only found a chain on a square whose four neighbours are all empty. The chain then starts with a single tile, and you get one free share in it.


## Single tiles

If you place a tile on a free square without founding, it stays a single tile: a grey block that belongs to no chain and is worth nothing.

Such a tile is only swallowed when somebody places a tile next to it that touches an existing chain at the same time. Then the new tile and its single neighbours all join that chain.

That is why placing next to a single tile is not allowed if you do not touch a chain. A chain would otherwise come into being unnoticed.


## What a share costs

price = base price + 100 for every threshold reached + 10 per share outstanding

| chain | base price |
|---|---|
| A and B | 900 |
| C | 800 |
| D and E | 700 |
| F | 600 |
| G | 500 |
| H | 400 |

The thresholds are at 1, 2, 3, 4, 5, 10, 15, 20, 25 and 36 tiles. So a chain of five tiles has reached five of them.

Example: chain C with five tiles costs 800 + 5 × 100 = 1300. If four shares of C are outstanding as well, it becomes 1340. A chain that does not exist costs nothing and cannot be bought.


## Mergers

If a placed tile touches two or more chains, the largest survives and the others are swallowed by it. If they are the same size, the player who places chooses.

For every swallowed chain this then happens:

- The bonus is worked out with the size and the price from before the merger: bonus = (number of tiles + shares outstanding) × share price.
- The bonus goes to the largest shareholders, usually two thirds to the first and one third to the second.
- Everyone gets one share in the surviving chain for every two in the chain that disappeared. The rest lapses.
- The chain that disappeared is back on the list and can be founded again.

| situation | split |
|---|---|
| only one shareholder | everything to them |
| numbers 1, 2 and 3 equal | a third each |
| numbers 1 and 2 equal | half each |
| numbers 2 and 3 equal | ⅔ — ⅙ — ⅙ |
| numbers 2 to 4 equal | ⅔ and the rest in three |
| numbers 2 to 5 equal | ⅔ and the rest in four |
| numbers 2 to 6 equal | ⅔ and the rest in five |
| otherwise | ⅔ — ⅓ |

Example: chain A has three tiles at a share price of 1300; ten shares are outstanding, held 6 – 3 – 1. A merges into B. The bonus is (3 + 10) × 1300 = 16,900. The largest shareholder gets 11,267, the second 5,633, the third nothing. Their shares become 3, 1 and 0 shares of B.

If three chains merge at once, this is done for each swallowed chain separately.


## When the game ends

- a chain grows larger than 100 tiles;
- 210 turns have been played (35 rounds);
- nobody can place a tile for a whole round.

Then comes the final standing on net worth: your cash plus the value of all your shares at the current price. The six results go into the high score list, which keeps the thirty largest fortunes.


## What it comes down to

- Founding is free money: you get a share without paying, and you choose the colour yourself.
- You earn from chains that disappear, not from chains that grow. The bonus only falls at a merger.
- Watch the shares block: only the largest and the second largest shareholder are paid at a merger.
- A chain that is already very large is rarely swallowed — but its shares do count towards your final worth.
- A tile you cannot place stays in the way; you only draw a new one once you have played one.

