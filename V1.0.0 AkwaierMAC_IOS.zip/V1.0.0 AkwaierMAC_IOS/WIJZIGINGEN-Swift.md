# Wat de Swift-versie anders doet dan de Windows-versie

Bijhouden zoals bij Klaverjas: alles wat hier staat, kan de C#-kant later dezelfde
kant op, zodat de twee dezelfde partij blijven spelen. De **spelregels zijn niet
aangeraakt** — `swift test` doorstaat alle tien de proeven, waaronder zestig
volledig uitgespeelde partijen.

## 1. Teksten die in Windows in de schermcode stonden

`Taal.swift` heeft er een blok bij, onder de kop *alleen in de Swift-versie*. In
de Windows-versie stonden deze teksten los in de WinForms-code; het scherm van de
iPad-versie mag geen enkele losse tekst bevatten, dus horen ze in `Taal`.

| naam | Nederlands | Engels |
|---|---|---|
| `weergaveModern` | Modern | Modern |
| `weergaveRetro` | Retro BBC | Retro BBC |
| `taalNederlands` | Nederlands | Nederlands |
| `taalEngels` | English | English |
| `tabBord` | Bord | Board |
| `tabPaneel` | Gegevens | Figures |
| `tabMeldingen` | Meldingen | Log |
| `eindstand` | Eindstand | Final standing |
| `standaardNaam` | ED | ED |

De namen van de weergaven en de talen zijn eigennamen en in beide talen gelijk.
`standaardNaam` staat al ingevuld in het startvenster, zodat je niet elke partij
je naam hoeft te typen; overtypen kan gewoon.
De drie `tab`-teksten staan boven de keuzeknop die op een smal scherm tussen bord,
gegevens en meldingen wisselt; die knop bestaat in Windows niet.

**Voor de C#-kant:** deze acht in `Taal.cs` overnemen als daar hetzelfde nodig is.

## 2. Eén tekst anders geformuleerd

`Taal.kiesEenSteen` was *"Kies een steen: tik op het bord of op je hand."* en is nu:

```
nl  Kies een steen.
en  Pick a tile.
```

Waar je moet tikken staat al op het scherm zelf — de handstrook en de genummerde
vakjes op het bord — dus die uitleg hoeft er niet bij.

`Taal.kiesEenSteenKort` ("Kies een steen op het bord of in je hand.") is nog niet
mee veranderd; die staat gedempt in beeld als je niet aan de beurt bent.

## 3. Passen levert geen koopbeurt op

Kan de speler geen enkele steen kwijt, dan verschijnt *Pas deze beurt* en gaat de
beurt daarna meteen naar de volgende speler — zonder koopfase. Dat is precies wat
`Spel.computerBeurt` voor de computerspelers doet (`past()` en dan terug), dus de
mens speelt hier dezelfde partij als de computer. Doet de Windows-versie hier wél
een koopronde, dan wijkt dat af en moet één van de twee bij.

## 4. Er staan twee dingen meer in het scorebestand

`Scorebestand` heeft er twee velden bij, naast `taal` en `scores`:

| veld | wat erin staat |
|---|---|
| `naam` | de naam waarmee de vorige partij gespeeld is; die staat de volgende keer al ingevuld |
| `weergave` | `modern` of `retro`, de weergave van de vorige keer |

`Scorebestand.init(from:)` is met de hand geschreven en gebruikt `decodeIfPresent`:
een bestand van vóór deze versie mist die twee sleutels, en dat mag de ranglijst
niet wissen.

De eerste keer, als er nog niets bewaard is, begint het spel in **Retro BBC** —
de weergave met de kleuren van het BBC Micro-scherm.

**Voor de C#-kant:** wil Windows hetzelfde onthouden, dan horen die twee velden
ook in `Scorelijst.cs`, met dezelfde namen, zodat één bestand voor beide werkt.

## 5. Waar het scorebestand staat

Dit zat al in `Scorelijst.swift` en is geen nieuwe keuze, maar het staat hier voor
de volledigheid: op Windows staat `acquire-scores.json` naast het programma, op de
Mac en de iPad kan dat niet. Daar gaat het naar

```
~/Library/Containers/nl.EdSoft.Akwaier/Data/Library/Application Support/Akwaier/akwaier-scores.json   (Mac, gezandbakt)
```

en op de iPad naar dezelfde plek binnen de app. De taalkeuze staat in datzelfde
bestand.

## 6. De spelregels zitten in de kern

`Spelregels.swift` bevat de spelregels in het Nederlands en het Engels, in
stukjes: alinea's, opsommingen en tabelletjes. De app leest ze in het venster
*Spelregels*, en `swift run AkwaierSpelregels` schrijft er `SPELREGELS.md` en
`RULES.md` uit. Zo staat de tekst maar op één plek.

De Windows-versie heeft `HANDLEIDING.md` naast het programma en geen venster met
de regels erin. Wil Windows hetzelfde, dan kan `Spelregels.cs` dezelfde opzet
krijgen.

## 7. Een ander pictogram

Windows heeft `akwaier-pictogram.ico`: een donkergrijze tegel met de letter A.
De Apple-versie heeft een uitsnede van het bord in de Retro BBC-weergave uit een
echte partij — twee tegels C, een blok van vier G, een losse steen, en F en H in
de onderhoek. Dat leest op een pictogramformaat beter dan één letter, en het is
meteen te zien welk spel het is. Getekend door
`Akwaier/Gereedschap/MaakPictogram.swift`.

## 8. Wat er níet is overgenomen

- **Toetsen 1 tot en met 8** om een steen te kiezen. Op een iPad is er geen
  toetsenbord; op de Mac zou het kunnen, maar dan werkt het op één van de twee
  toestellen niet, en het bord en de handstrook doen hetzelfde werk.
- **Het foutbestand `acquire-fout.txt`.** Een app op iOS schrijft niet naast
  zichzelf; er is nog geen vervanger voor.
- **`Acquire.exe zelftest`** als losse aanroep. Op de Mac is dat
  `swift test` of `swift run AkwaierZelftest` in `AkwaierKern/`.
