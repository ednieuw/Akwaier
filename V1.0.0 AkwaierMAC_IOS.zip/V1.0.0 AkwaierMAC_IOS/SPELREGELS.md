# De spelregels van Akwaier

Een spel voor zes spelers, waarvan er één jij bent. Je legt om beurten een steen op een bord van 15 bij 15, daarmee groeien acht hotelketens, en je verdient geld door op tijd aandelen te kopen in de keten die straks door een ander wordt opgeslokt. Wie aan het eind het grootste vermogen heeft, wint.

Dit spel was oorspronkelijk geschreven voor een Acorn BBC Basic computer in 1987 en nu vertaald naar de Swift programmeertaal voor IOS en MacOS.

## Het bord

Rijen heten A tot en met O van boven naar beneden, kolommen 1 tot en met 15 van links naar rechts. Een vakje heet dus B7: rij B, kolom 7 — eerst de letter, dan het cijfer.

Er zijn 225 stenen, één voor elk vakje. Iedereen heeft er acht in de hand en trekt na elke zet een nieuwe uit de zak. Is de zak leeg, dan raakt de hand langzaam op.

| wat je ziet | wat het is |
|---|---|
| klein stipje | leeg vakje |
| grijs blokje | een losse steen, die bij geen keten hoort |
| gekleurd vak met letter | een tegel van keten A tot en met H |
| cijfer 1 t/m 8 | een van jouw acht stenen |
| oranje kader | de steen die je nu gekozen hebt |


## Een beurt

- Kies een steen: tik op je hand, of op het genummerde vakje op het bord.
- Leg hem neer, of sticht er een keten mee.
- Raakt hij twee even grote ketens, kies dan welke blijft bestaan.
- Koop daarna hoogstens drie aandelen van één keten, of koop niets.

Kun je met geen enkele steen iets, dan sla je de beurt over en koop je die beurt ook niet.


## Stichten

Een keten stichten kan alleen op een vakje waarvan alle vier de buren leeg zijn. De keten begint dan met één tegel, en jij krijgt er één gratis aandeel bij.


## Losse stenen

Leg je een steen op een vrij vakje zonder te stichten, dan blijft het een losse steen: een grijs blokje dat bij geen keten hoort en niets waard is.

Zo'n losse steen wordt pas opgeslokt als iemand er een steen naast legt die tegelijk een bestaande keten raakt. Dan gaan de nieuwe steen én de losse buren in die keten op.

Daarom geldt: naast een losse steen leggen mag niet als je geen keten raakt. Er zou anders ongemerkt een keten ontstaan.


## Wat een aandeel kost

prijs = basisprijs + 100 per gehaalde drempel + 10 per uitstaand aandeel

| keten | basisprijs |
|---|---|
| A en B | 900 |
| C | 800 |
| D en E | 700 |
| F | 600 |
| G | 500 |
| H | 400 |

De drempels liggen bij 1, 2, 3, 4, 5, 10, 15, 20, 25 en 36 tegels. Een keten van vijf tegels heeft er dus vijf gehaald.

Voorbeeld: keten C met vijf tegels kost 800 + 5 × 100 = 1300. Zijn er ook nog vier aandelen C in omloop, dan wordt het 1340. Een keten die niet bestaat kost niets en kun je niet kopen.


## Fusie

Raakt een gelegde steen twee of meer ketens, dan blijft de grootste bestaan en gaan de andere er helemaal in op. Bij gelijke grootte kiest de speler die legt.

Voor elke opgeslokte keten gebeurt er dan dit:

- De bonuspot wordt berekend met de grootte en de prijs van vóór de fusie: pot = (aantal tegels + aantal uitstaande aandelen) × aandeelprijs.
- De pot gaat naar de grootste aandeelhouders, meestal twee derde naar de eerste en een derde naar de tweede.
- Iedereen krijgt voor elke twee aandelen in de verdwenen keten er één in de winnende terug. De rest vervalt.
- De verdwenen keten staat daarna weer op de lijst en kan opnieuw gesticht worden.

| situatie | verdeling |
|---|---|
| maar één aandeelhouder | alles naar hem |
| nummers 1, 2 en 3 gelijk | elk een derde |
| nummers 1 en 2 gelijk | elk de helft |
| nummers 2 en 3 gelijk | ⅔ — ⅙ — ⅙ |
| nummers 2 t/m 4 gelijk | ⅔ en de rest in drieën |
| nummers 2 t/m 5 gelijk | ⅔ en de rest in vieren |
| nummers 2 t/m 6 gelijk | ⅔ en de rest in vijven |
| anders | ⅔ — ⅓ |

Voorbeeld: keten A heeft drie tegels bij een aandeelprijs van 1300; er zijn tien aandelen in omloop, verdeeld als 6 – 3 – 1. A gaat op in B. De pot is (3 + 10) × 1300 = 16.900. De grootste aandeelhouder krijgt 11.267, de tweede 5.633, de derde niets. Hun aandelen worden 3, 1 en 0 aandelen B.

Fuseren drie ketens tegelijk, dan gaat dit voor elke opgeslokte keten apart.


## Wanneer het spel eindigt

- een keten wordt groter dan 100 tegels;
- er zijn 210 beurten gespeeld (35 rondes);
- niemand kan een ronde lang nog een steen kwijt.

Daarna volgt de eindstand op vermogen: je geld plus de waarde van al je aandelen tegen de huidige prijs. De zes uitslagen gaan de scorelijst in, die de dertig hoogste vermogens bewaart.


## Waar het om draait

- Stichten is gratis geld: je krijgt er een aandeel bij zonder te betalen, en je bepaalt zelf welke kleur.
- Je verdient aan ketens die verdwijnen, niet aan ketens die groeien. De bonus valt alleen bij een fusie.
- Kijk naar het aandelenblok: alleen de grootste en de op één na grootste aandeelhouder krijgen bij een fusie geld.
- Een keten die al heel groot is, wordt zelden nog opgeslokt — maar de aandelen tellen wel mee in je eindvermogen.
- Een steen die je niet kwijt kunt blijft in de weg liggen; je trekt pas een nieuwe als je er een gespeeld hebt.

