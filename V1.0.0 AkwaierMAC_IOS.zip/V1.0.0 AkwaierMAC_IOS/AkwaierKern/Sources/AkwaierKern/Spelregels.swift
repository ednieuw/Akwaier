import Foundation

/// Een stuk van de spelregels: een alinea, een opsomming of een tabelletje.
public enum Spelregeldeel {
    case alinea(String)
    case opsomming([String])
    case tabel(koppen: [String], rijen: [[String]])
}

/// Eén hoofdstukje van de spelregels.
public struct Spelregelblok {
    public let kop: String
    public let delen: [Spelregeldeel]

    public init(_ kop: String, _ delen: [Spelregeldeel]) {
        self.kop = kop
        self.delen = delen
    }
}

/// De spelregels, in het Nederlands en het Engels. Dit is dezelfde tekst als in
/// `Referentie/HANDLEIDING.md`, ingekort tot wat je tijdens het spelen wilt
/// kunnen opzoeken.
///
/// Het scherm haalt ze hier op, en `swift run AkwaierSpelregels` schrijft er
/// `SPELREGELS.md` en `RULES.md` uit. Zo staat er maar op één plek tekst en
/// kunnen de app en de bestanden niet uit elkaar lopen.
public enum Spelregels {

    public static var titel: String {
        Taal.engels ? "The rules of Akwaier" : "De spelregels van Akwaier"
    }

    public static var inleiding: String {
        Taal.engels
            ? """
              A game for six players, one of whom is you. In turn you place a tile \
              on a board of 15 by 15. Eight hotel chains grow on it, and you earn \
              money by buying shares in time in the chain that another player is \
              about to swallow. Whoever has the largest net worth at the end wins.
              """
            : """
              Een spel voor zes spelers, waarvan er één jij bent. Je legt om beurten \
              een steen op een bord van 15 bij 15, daarmee groeien acht hotelketens, \
              en je verdient geld door op tijd aandelen te kopen in de keten die \
              straks door een ander wordt opgeslokt. Wie aan het eind het grootste \
              vermogen heeft, wint.
              """
    }

    public static var herkomst: String {
        Taal.engels
            ? """
              These are the rules of the BBC Micro program AQUIRE.BBC from 1987, \
              not those of Sid Sackson's board game. On two points it clearly \
              differs: see the sections Founding and Single tiles.
              """
            : """
              Dit zijn de regels van het BBC Micro-programma AQUIRE.BBC uit 1987, \
              niet die van het bordspel van Sid Sackson. Op twee punten wijkt het \
              duidelijk af: zie de kopjes Stichten en Losse stenen.
              """
    }

    public static var blokken: [Spelregelblok] { Taal.engels ? engels : nederlands }

    // MARK: - Nederlands

    private static let nederlands: [Spelregelblok] = [
        Spelregelblok("Het bord", [
            .alinea("""
                    Rijen heten A tot en met O van boven naar beneden, kolommen 1 tot \
                    en met 15 van links naar rechts. Een vakje heet dus B7: rij B, \
                    kolom 7 — eerst de letter, dan het cijfer.
                    """),
            .alinea("""
                    Er zijn 225 stenen, één voor elk vakje. Iedereen heeft er acht in \
                    de hand en trekt na elke zet een nieuwe uit de zak. Is de zak leeg, \
                    dan raakt de hand langzaam op.
                    """),
            .tabel(koppen: ["wat je ziet", "wat het is"], rijen: [
                ["klein stipje", "leeg vakje"],
                ["grijs blokje", "een losse steen, die bij geen keten hoort"],
                ["gekleurd vak met letter", "een tegel van keten A tot en met H"],
                ["cijfer 1 t/m 8", "een van jouw acht stenen"],
                ["oranje kader", "de steen die je nu gekozen hebt"],
            ]),
        ]),

        Spelregelblok("Een beurt", [
            .opsomming([
                "Kies een steen: tik op je hand, of op het genummerde vakje op het bord.",
                "Leg hem neer, of sticht er een keten mee.",
                "Raakt hij twee even grote ketens, kies dan welke blijft bestaan.",
                "Koop daarna hoogstens drie aandelen van één keten, of koop niets.",
            ]),
            .alinea("""
                    Kun je met geen enkele steen iets, dan sla je de beurt over en koop \
                    je die beurt ook niet.
                    """),
        ]),

        Spelregelblok("Stichten", [
            .alinea("""
                    Een keten stichten kan alleen op een vakje waarvan alle vier de \
                    buren leeg zijn. De keten begint dan met één tegel, en jij krijgt \
                    er één gratis aandeel bij.
                    """),
            .alinea("""
                    Dit is het grootste verschil met het bordspel Acquire, waar een \
                    keten ontstaat door naast een losse steen te leggen. Hier gaat het \
                    andersom, en dat is geen fout in de omzetting.
                    """),
        ]),

        Spelregelblok("Losse stenen", [
            .alinea("""
                    Leg je een steen op een vrij vakje zonder te stichten, dan blijft \
                    het een losse steen: een grijs blokje dat bij geen keten hoort en \
                    niets waard is.
                    """),
            .alinea("""
                    Zo'n losse steen wordt pas opgeslokt als iemand er een steen naast \
                    legt die tegelijk een bestaande keten raakt. Dan gaan de nieuwe \
                    steen én de losse buren in die keten op.
                    """),
            .alinea("""
                    Daarom geldt: naast een losse steen leggen mag niet als je geen \
                    keten raakt. Er zou anders ongemerkt een keten ontstaan.
                    """),
        ]),

        Spelregelblok("Wat een aandeel kost", [
            .alinea("prijs = basisprijs + 100 per gehaalde drempel + 10 per uitstaand aandeel"),
            .tabel(koppen: ["keten", "basisprijs"], rijen: [
                ["A en B", "900"], ["C", "800"], ["D en E", "700"],
                ["F", "600"], ["G", "500"], ["H", "400"],
            ]),
            .alinea("""
                    De drempels liggen bij 1, 2, 3, 4, 5, 10, 15, 20, 25 en 36 tegels. \
                    Een keten van vijf tegels heeft er dus vijf gehaald.
                    """),
            .alinea("""
                    Voorbeeld: keten C met vijf tegels kost 800 + 5 × 100 = 1300. Zijn \
                    er ook nog vier aandelen C in omloop, dan wordt het 1340. Een keten \
                    die niet bestaat kost niets en kun je niet kopen.
                    """),
        ]),

        Spelregelblok("Fusie", [
            .alinea("""
                    Raakt een gelegde steen twee of meer ketens, dan blijft de grootste \
                    bestaan en gaan de andere er helemaal in op. Bij gelijke grootte \
                    kiest de speler die legt.
                    """),
            .alinea("Voor elke opgeslokte keten gebeurt er dan dit:"),
            .opsomming([
                "De bonuspot wordt berekend met de grootte en de prijs van vóór de fusie: pot = (aantal tegels + aantal uitstaande aandelen) × aandeelprijs.",
                "De pot gaat naar de grootste aandeelhouders, meestal twee derde naar de eerste en een derde naar de tweede.",
                "Iedereen krijgt voor elke twee aandelen in de verdwenen keten er één in de winnende terug. De rest vervalt.",
                "De verdwenen keten staat daarna weer op de lijst en kan opnieuw gesticht worden.",
            ]),
            .tabel(koppen: ["situatie", "verdeling"], rijen: [
                ["maar één aandeelhouder", "alles naar hem"],
                ["nummers 1, 2 en 3 gelijk", "elk een derde"],
                ["nummers 1 en 2 gelijk", "elk de helft"],
                ["nummers 2 en 3 gelijk", "⅔ — ⅙ — ⅙"],
                ["nummers 2 t/m 4 gelijk", "⅔ en de rest in drieën"],
                ["nummers 2 t/m 5 gelijk", "⅔ en de rest in vieren"],
                ["nummers 2 t/m 6 gelijk", "⅔ en de rest in vijven"],
                ["anders", "⅔ — ⅓"],
            ]),
            .alinea("""
                    Voorbeeld: keten A heeft drie tegels bij een aandeelprijs van 1300; \
                    er zijn tien aandelen in omloop, verdeeld als 6 – 3 – 1. A gaat op \
                    in B. De pot is (3 + 10) × 1300 = 16.900. De grootste aandeelhouder \
                    krijgt 11.267, de tweede 5.633, de derde niets. Hun aandelen worden \
                    3, 1 en 0 aandelen B.
                    """),
            .alinea("Fuseren drie ketens tegelijk, dan gaat dit voor elke opgeslokte keten apart."),
        ]),

        Spelregelblok("Wanneer het spel afloopt", [
            .opsomming([
                "een keten wordt groter dan 100 tegels;",
                "er zijn 210 beurten gespeeld (35 rondes);",
                "niemand kan een ronde lang nog een steen kwijt.",
            ]),
            .alinea("""
                    Daarna volgt de eindstand op vermogen: je geld plus de waarde van al \
                    je aandelen tegen de huidige prijs. De zes uitslagen gaan de \
                    scorelijst in, die de dertig hoogste vermogens bewaart.
                    """),
        ]),

        Spelregelblok("Waar het om draait", [
            .opsomming([
                "Stichten is gratis geld: je krijgt er een aandeel bij zonder te betalen, en je bepaalt zelf welke kleur.",
                "Je verdient aan ketens die verdwijnen, niet aan ketens die groeien. De bonus valt alleen bij een fusie.",
                "Kijk naar het aandelenblok: alleen de grootste en de op één na grootste aandeelhouder krijgen bij een fusie geld.",
                "Een keten die al heel groot is, wordt zelden nog opgeslokt — maar de aandelen tellen wel mee in je eindvermogen.",
                "Een steen die je niet kwijt kunt blijft in de weg liggen; je trekt pas een nieuwe als je er een gespeeld hebt.",
            ]),
        ]),
    ]

    // MARK: - Engels

    private static let engels: [Spelregelblok] = [
        Spelregelblok("The board", [
            .alinea("""
                    Rows are named A to O from top to bottom, columns 1 to 15 from left \
                    to right. So a square is called B7: row B, column 7 — the letter \
                    first, then the number.
                    """),
            .alinea("""
                    There are 225 tiles, one for every square. Everyone holds eight and \
                    draws a new one from the bag after each move. Once the bag is empty, \
                    your hand slowly runs out.
                    """),
            .tabel(koppen: ["what you see", "what it is"], rijen: [
                ["small dot", "empty square"],
                ["grey block", "a single tile, belonging to no chain"],
                ["coloured square with a letter", "a tile of chain A to H"],
                ["number 1 to 8", "one of your eight tiles"],
                ["orange frame", "the tile you have picked"],
            ]),
        ]),

        Spelregelblok("A turn", [
            .opsomming([
                "Pick a tile: tap your hand, or the numbered square on the board.",
                "Place it, or found a chain with it.",
                "If it touches two chains of equal size, choose which one survives.",
                "Then buy at most three shares in one chain, or buy nothing.",
            ]),
            .alinea("""
                    If you cannot place a single tile, you pass, and you do not buy that \
                    turn either.
                    """),
        ]),

        Spelregelblok("Founding", [
            .alinea("""
                    You can only found a chain on a square whose four neighbours are all \
                    empty. The chain then starts with a single tile, and you get one free \
                    share in it.
                    """),
            .alinea("""
                    This is the biggest difference from the board game Acquire, where a \
                    chain comes into being by placing next to a single tile. Here it \
                    works the other way round, and that is not a mistake in the port.
                    """),
        ]),

        Spelregelblok("Single tiles", [
            .alinea("""
                    If you place a tile on a free square without founding, it stays a \
                    single tile: a grey block that belongs to no chain and is worth \
                    nothing.
                    """),
            .alinea("""
                    Such a tile is only swallowed when somebody places a tile next to it \
                    that touches an existing chain at the same time. Then the new tile \
                    and its single neighbours all join that chain.
                    """),
            .alinea("""
                    That is why placing next to a single tile is not allowed if you do \
                    not touch a chain. A chain would otherwise come into being unnoticed.
                    """),
        ]),

        Spelregelblok("What a share costs", [
            .alinea("price = base price + 100 for every threshold reached + 10 per share outstanding"),
            .tabel(koppen: ["chain", "base price"], rijen: [
                ["A and B", "900"], ["C", "800"], ["D and E", "700"],
                ["F", "600"], ["G", "500"], ["H", "400"],
            ]),
            .alinea("""
                    The thresholds are at 1, 2, 3, 4, 5, 10, 15, 20, 25 and 36 tiles. So \
                    a chain of five tiles has reached five of them.
                    """),
            .alinea("""
                    Example: chain C with five tiles costs 800 + 5 × 100 = 1300. If four \
                    shares of C are outstanding as well, it becomes 1340. A chain that \
                    does not exist costs nothing and cannot be bought.
                    """),
        ]),

        Spelregelblok("Mergers", [
            .alinea("""
                    If a placed tile touches two or more chains, the largest survives and \
                    the others are swallowed by it. If they are the same size, the player \
                    who places chooses.
                    """),
            .alinea("For every swallowed chain this then happens:"),
            .opsomming([
                "The bonus is worked out with the size and the price from before the merger: bonus = (number of tiles + shares outstanding) × share price.",
                "The bonus goes to the largest shareholders, usually two thirds to the first and one third to the second.",
                "Everyone gets one share in the surviving chain for every two in the chain that disappeared. The rest lapses.",
                "The chain that disappeared is back on the list and can be founded again.",
            ]),
            .tabel(koppen: ["situation", "split"], rijen: [
                ["only one shareholder", "everything to them"],
                ["numbers 1, 2 and 3 equal", "a third each"],
                ["numbers 1 and 2 equal", "half each"],
                ["numbers 2 and 3 equal", "⅔ — ⅙ — ⅙"],
                ["numbers 2 to 4 equal", "⅔ and the rest in three"],
                ["numbers 2 to 5 equal", "⅔ and the rest in four"],
                ["numbers 2 to 6 equal", "⅔ and the rest in five"],
                ["otherwise", "⅔ — ⅓"],
            ]),
            .alinea("""
                    Example: chain A has three tiles at a share price of 1300; ten shares \
                    are outstanding, held 6 – 3 – 1. A merges into B. The bonus is \
                    (3 + 10) × 1300 = 16,900. The largest shareholder gets 11,267, the \
                    second 5,633, the third nothing. Their shares become 3, 1 and 0 \
                    shares of B.
                    """),
            .alinea("If three chains merge at once, this is done for each swallowed chain separately."),
        ]),

        Spelregelblok("When the game ends", [
            .opsomming([
                "a chain grows larger than 100 tiles;",
                "210 turns have been played (35 rounds);",
                "nobody can place a tile for a whole round.",
            ]),
            .alinea("""
                    Then comes the final standing on net worth: your cash plus the value \
                    of all your shares at the current price. The six results go into the \
                    high score list, which keeps the thirty largest fortunes.
                    """),
        ]),

        Spelregelblok("What it comes down to", [
            .opsomming([
                "Founding is free money: you get a share without paying, and you choose the colour yourself.",
                "You earn from chains that disappear, not from chains that grow. The bonus only falls at a merger.",
                "Watch the shares block: only the largest and the second largest shareholder are paid at a merger.",
                "A chain that is already very large is rarely swallowed — but its shares do count towards your final worth.",
                "A tile you cannot place stays in the way; you only draw a new one once you have played one.",
            ]),
        ]),
    ]
}
