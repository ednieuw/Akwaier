import Foundation
import AkwaierKern

// Schrijft de spelregels uit `Spelregels.swift` weg als Markdown, in allebei de
// talen. Draaien vanuit deze map:
//
//     swift run AkwaierSpelregels
//
// De bestanden komen een map hoger te staan, naast LEESMIJ.md.

func markdown() -> String {
    var uit = "# \(Spelregels.titel)\n\n\(Spelregels.inleiding)\n\n\(Spelregels.herkomst)\n"
    for blok in Spelregels.blokken {
        uit += "\n## \(blok.kop)\n\n"
        for deel in blok.delen {
            switch deel {
            case .alinea(let tekst):
                uit += "\(tekst)\n\n"
            case .opsomming(let punten):
                for punt in punten { uit += "- \(punt)\n" }
                uit += "\n"
            case .tabel(let koppen, let rijen):
                uit += "| " + koppen.joined(separator: " | ") + " |\n"
                uit += "|" + koppen.map { _ in "---" }.joined(separator: "|") + "|\n"
                for rij in rijen { uit += "| " + rij.joined(separator: " | ") + " |\n" }
                uit += "\n"
            }
        }
    }
    let voet = Taal.engels
        ? """
          *Written by `swift run AkwaierSpelregels`. The text itself lives in \
          `AkwaierKern/Sources/AkwaierKern/Spelregels.swift` and is the same as in \
          the app's Rules window. Change it there, not here.*
          """
        : """
          *Geschreven door `swift run AkwaierSpelregels`; de tekst zelf staat in \
          `AkwaierKern/Sources/AkwaierKern/Spelregels.swift` en is dezelfde als in \
          het venster Spelregels van de app. Wijzig hem daar, niet hier.*
          """
    return uit + "\n---\n\n" + voet + "\n"
}

let hier = URL(fileURLWithPath: FileManager.default.currentDirectoryPath)
let map = hier.lastPathComponent == "AkwaierKern" ? hier.deletingLastPathComponent() : hier

Taal.engels = false
try? markdown().write(to: map.appendingPathComponent("SPELREGELS.md"),
                      atomically: true, encoding: .utf8)
print("SPELREGELS.md geschreven")

Taal.engels = true
try? markdown().write(to: map.appendingPathComponent("RULES.md"),
                      atomically: true, encoding: .utf8)
print("RULES.md geschreven")
