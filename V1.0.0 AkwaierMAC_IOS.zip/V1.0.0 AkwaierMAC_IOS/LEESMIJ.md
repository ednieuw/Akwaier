# Akwaier — map voor de MacBook

Deze map is bedoeld om in zijn geheel naar de MacBook gekopieerd te worden. Daar
laat je Claude Code er de iPad/Mac-versie van bouwen.

## Waar te beginnen

1. **`OPDRACHT.md`** — geef dit aan Claude Code op de Mac. Daar staat wat er
   gebouwd moet worden, in welke volgorde, en welke vier valkuilen er zijn.
2. `AkwaierKern/` — de spelkern is er al, in Swift. Eerst `swift test` draaien.
3. `Referentie/` — alles om op terug te vallen.

## Draaien

```bash
open Akwaier/Akwaier.xcodeproj
```

Kies boven in Xcode *My Mac*, een iPad- of een iPhone-simulator en druk op Start.
Vanaf de opdrachtregel kan het ook:

```bash
xcodebuild -project Akwaier/Akwaier.xcodeproj -scheme Akwaier -destination 'platform=macOS' build
```

De proeven van de spelkern draaien los, zonder Xcode:

```bash
cd AkwaierKern && swift test
```

De spelregels staan in de kern, in beide talen, en zijn in de app te lezen met de
knop *Spelregels*. Dit schrijft dezelfde tekst weg als `SPELREGELS.md` en
`RULES.md`:

```bash
cd AkwaierKern && swift run AkwaierSpelregels
```

## De naam

Het spel heet **Akwaier**. Acquire is de naam van het bordspel van Sid Sackson;
die gebruiken we niet in de app, de bundle-id of op het scherm. Alleen de
bestanden van het origineel uit 1987 houden hun naam `AQUIRE.*` — zo heetten ze.

De Windows-versie in `..\ACQUIRE\` heet nog Acquire. Wil je die ook omdopen, dan
is dat dezelfde ingreep: hernoemen van map, project, naamruimte en de teksten in
`Taal.cs`.

## Inhoud

```
OPDRACHT.md                      de opdracht voor Claude Code op de Mac
LEESMIJ.md                       dit bestand
WIJZIGINGEN-Swift.md             waar de Swift-versie van Windows afwijkt
SPELREGELS.md                    de spelregels, Nederlands  (geschreven door de kern)
RULES.md                         de spelregels, Engels      (geschreven door de kern)

Akwaier/                         het Xcode-project (iPad, iPhone en Mac)
  Akwaier.xcodeproj              multiplatform App-target, AkwaierKern als lokale package
  Akwaier/                       de SwiftUI-code
    AkwaierApp.swift             het beginpunt
    Spelmodel.swift              de beurtloop en een afdruk van de stand voor het scherm
    Weergave/                    bord, paneel, hand, knoppen, meldingen, start, scores
    Assets.xcassets              het pictogram
  Gereedschap/MaakPictogram.swift tekent dat pictogram opnieuw
  Gereedschap/maak-dmg.sh        bouwt de Mac-app en maakt er een schijfkopie van

AkwaierDMG/                      de schijfkopie voor de Mac

AkwaierKern/                     SwiftPM-package met de spelkern
  Package.swift
  Sources/AkwaierKern/
    Regels.swift                 vaste getallen, steennummer -> vakje, toevalsreeks
    Speler.swift                 speler, zetkans, uitkering, zetverslag
    Bonus.swift                  de verdeelsleutel van de fusiebonus
    Spel.swift                   alle regels: leggen, stichten, fuseren, kopen, de AI
    Taal.swift                   alle teksten, Nederlands en Engels
    Scorelijst.swift             scorebestand en taalkeuze
    Zelftest.swift               tien proeven, waaronder zestig hele partijen
  Sources/AkwaierZelftest/       swift run AkwaierZelftest
  Tests/AkwaierKernTests/        swift test, en Product > Test in Xcode

Referentie/
  AQUIRE_detokenized.bas         de originele BBC BASIC-broncode uit 1987
  CSharp-engine/*.cs             dezelfde kern in C#, de bron van de vertaling
  HANDLEIDING.md                 de volledige spelregels in gewone taal
  schermbeeld-*.png              hoe de Windows-versie eruitziet
  akwaier-pictogram.ico          het pictogram (moet nog naar .icns/asset catalog)
  make_icon.py                   het scriptje dat dat pictogram tekent
```

## Wat er af is

Op de Mac gebouwd met Xcode 26.6 (Swift 6.3), 23 augustus 2026:

- **De kern draait.** De Swift-code uit `AkwaierKern/` compileerde in één keer;
  er hoefde geen enkele compilerfout uit. `swift test` is groen: drie proeven,
  waaronder de tien controles en zestig volledig uitgespeelde partijen.
- **Het scherm is er**, in `Akwaier/`: een multiplatform SwiftUI-app voor iPad,
  iPhone en Mac, met `AkwaierKern` als lokale package. Uitgeprobeerd op een
  iPad Air 11" (staand en liggend), een iPhone 16 en macOS 26.5.
- **Het pictogram** zit in de asset catalog: een uitsnede van het bord in de
  Retro BBC-weergave, uit een echte partij (zaad 4, beurt 120, rij C t/m F,
  kolom 4 t/m 7). `swift Akwaier/Gereedschap/MaakPictogram.swift` tekent hem
  opnieuw — dicht en vierkant voor iOS, met ronde hoeken en een marge voor de
  Mac. De tegel met de A uit `Referentie/make_icon.py` is daarmee vervallen.

## Wat er nog niet is

- **Een schijfkopie om weg te geven.** `Akwaier/Gereedschap/maak-dmg.sh` maakt
  `AkwaierDMG/Akwaier-1.0.dmg`, maar die is ondertekend met het
  ontwikkelcertificaat. Op je eigen Mac opent hij; op andermans Mac houdt
  Gatekeeper hem tegen. Daarvoor is een *Developer ID Application*-certificaat
  nodig (Xcode > Settings > Accounts > Manage Certificates > +) en daarna
  notariseren met `notarytool` en `stapler`. Het script zegt zelf welke stap
  er nog mist.
- **De App Store.** Het project staat op *Automatic* met team U533G62Q3B; er is
  nog niets ingeleverd.
- **Het foutbestand.** De Windows-versie schrijft `acquire-fout.txt` naast het
  programma; op iOS kan dat niet en er is nog geen vervanger. Zie
  `WIJZIGINGEN-Swift.md`.

## Gelijk houden met Windows

Wijkt de Swift-versie ergens van de Windows-versie af, dan staat dat in
`WIJZIGINGEN-Swift.md` in deze map — dezelfde werkwijze als bij Klaverjas. Daar
staat nu al in wat er in `Taal` bij is gekomen en welke tekst anders luidt. Dan
kan de C#-kant dezelfde kant op en blijven de twee dezelfde partij spelen.
